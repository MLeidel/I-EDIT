#console_log for Php

Lifted code from php.net documentation

<small>console_log.php contains the following code:</small>
```php
function console_log( $data ) {
  echo '<script>';
  echo 'console.log('. json_encode( $data ) .')';
  echo '</script>';
}
```

Sample usage:
```php
include "console_log";

$aryvar = array(1,2,3);
$a = "some string value";
$b = 1231.21;

console_log($a);
console_log("var \$a = " . $a);
console_log( $aryvar );
console_log( [$a, $b, $aryvar] );
```

Output in the console:

![alttext](../images/console.png "title")