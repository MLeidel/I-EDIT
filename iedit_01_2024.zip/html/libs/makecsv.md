<?php // makecsv.php

function makecsv($dbname, $sql, $head, $outfile) {
  $db = new SQLite3($dbname);
  $tout = $head . PHP_EOL;
  $results = $db->query($sql);
  $ar = $results->fetchArray(SQLITE3_NUM);
  if (!$ar) {
  	die("No rows returned");
  }

  do {
  	for($x=0; $x < count($ar) - 1; $x++) {
  		$tout .= "\"$ar[$x]\",";
  	}
  	$tout .= "\"$ar[$x]\"" . PHP_EOL;

  } while ( $ar = $results->fetchArray(SQLITE3_NUM) );

  if ($outfile !== null) {
    file_put_contents( $outfile, $tout );
  } else {
    return $tout;
  }
}
?>