
#Tblrows

include "libs/Tblrows.php";

Helps format data into an HTML a table.
Formats HTML table one row at a time.
The row can be in the form of: a string
with comma delimited values; an
array; or a row returned from
a database resultset. These
functions will not create the HTML
`<table>` and `</table>` tags. That and
any styling are left to the coder.

  *[Optionally, the 1st column of the
  constructed HTML table may contain
  a link to a Javascript function
  whose single parameter value is determined
  by the last column value of the input
  array or resultset row. When this
  option is used do not include the 
  column NAME for that column in 
  the table heading. You will have to
  provide the actual Javascript 
  function in your rendered page.]*

---
###Class: Tblrow(string)

Constructor sets the column formats:
* **>**     left justify column data
* **d**     format to *.99 and right justify
* **\>**    right justify column data
* **\-**    center column data

Example: 
```php
$tbl = new Tblrow("<,<,d,>,<");  // no optional link column
$tbl = new Tblrow("<,<,d,>,<", "alert");  // link function name
```

###function: tblhead(array|string)

The HTML table heading may be provided in one of two ways:
* string with comma delimited values
* array of string values

Examples:
```php
$tbl->tblhead("Name,Email,Amount,Account,Type");  // string with csv
$tbl->tblhead( array("Name","Email","Amount","Account","Type") );  // array
```
By using an array for headings you can add more functionality as shown below.
```
$ahead = array(
  "<a onclick='alert(0);'>Memory, of</a>",
  "<a onclick='alert(1);'>Amount</a>",
  "<a onclick='alert(2);'>Remarks</a>",
  "<a onclick='alert(\"Three\", 3);'>Attended</a>"
  );
echo $Trow->tblhead($ahead);  // array

```
---

###function: tblrow(array | csv)

Example:
```php
tbl->tblrow($Data); // array or row from resultset or csv string
tbl->tblrow(array("John Doe","abc@hello.com",123.99,"01001234","active"));  // array
tbl->tblrow("John Doe,abc@123.com,100.90,01001234,closed");  //  simple csv string
```
Below is an example for coding and SQL query result.
This example uses the optional function name in the constructor
which will create a column 1 of function links whose parameter
value will be the last column value of the resultset rows. In
this example that value would be the database column `member_rowid`.
```php
include "Tblrows.php";

$db = new SQLite3('savetest.db');

$sql = "SELECT in_mem_honor, amount_paid, remarks, attended, member_rowid
from tbldonation
where in_mem_honor <> ''";  // the query string

$results = $db->query($sql);  // query database
$ar = $results->fetchArray(SQLITE3_NUM); // get the 1st row (array)
if (!$ar) {
	die("No rows returned");
}

//  instantiate a Tblrow class object
$Trow = new Tblrow("<,d,<,-", "alert");  // using optional function name

//  print the open table tag
echo "<table cellspacing=0 cellpadding=4 border=1>\n";  

//  create the table headings row with the tblhead method
echo $Trow->tblhead("Memory of,Amount,Remarks,Attended");  // 1 string arg

//  loop through resultset outputting each formatted table row
do {
  
  echo $Trow->tblrow($ar); // each row of resultset is an array

} while ( $ar = $results->fetchArray(SQLITE3_NUM) );

echo "</table>\n";  // print the close table tag

```

<table cellspacing=0 cellpadding=4 border=1>
<tr><th>^</th><th>Memory of</th><th>Amount</th><th>Remarks</th><th>Attended</th></tr>
<tr><td><a onclick="alert(12);">&nbsp;&nbsp;&raquo;&nbsp;&nbsp;</a></td><td>mom</td><td align='right'>1,000.00</td><td></td><td align='center'></td></tr>
<tr><td><a onclick="alert(49);">&nbsp;&nbsp;&raquo;&nbsp;&nbsp;</a></td><td>Antony and Cleopatra</td><td align='right'>11.00</td><td>Testing</td><td align='center'></td></tr>
<tr><td><a onclick="alert(5);">&nbsp;&nbsp;&raquo;&nbsp;&nbsp;</a></td><td>Sponsor</td><td align='right'>250.00</td><td></td><td align='center'>1</td></tr>
<tr><td><a onclick="alert(36);">&nbsp;&nbsp;&raquo;&nbsp;&nbsp;</a></td><td>Sponsor</td><td align='right'>250.00</td><td></td><td align='center'></td></tr>
<tr><td><a onclick="alert(9);">&nbsp;&nbsp;&raquo;&nbsp;&nbsp;</a></td><td>Sponsor</td><td align='right'>300.00</td><td></td><td align='center'>1</td></tr>
<tr><td><a onclick="alert(50);">&nbsp;&nbsp;&raquo;&nbsp;&nbsp;</a></td><td>Sponsor</td><td align='right'>300.00</td><td>';sql injection</td><td align='center'>1</td></tr>
<tr><td><a onclick="alert(54);">&nbsp;&nbsp;&raquo;&nbsp;&nbsp;</a></td><td>Chocolate Factory</td><td align='right'>22.22</td><td>Irish Cats Love
Chocolate</td><td align='center'>1</td></tr>
<tr><td><a onclick="alert(54);">&nbsp;&nbsp;&raquo;&nbsp;&nbsp;</a></td><td>sponsor</td><td align='right'>250.00</td><td></td><td align='center'>1</td></tr>
<tr><td><a onclick="alert(58);">&nbsp;&nbsp;&raquo;&nbsp;&nbsp;</a></td><td>The Star</td><td align='right'>250.00</td><td>Test</td><td align='center'>1</td></tr>
<tr><td><a onclick="alert(60);">&nbsp;&nbsp;&raquo;&nbsp;&nbsp;</a></td><td>Jack Black</td><td align='right'>250.00</td><td>KOOL</td><td align='center'>1</td></tr>
<tr><td><a onclick="alert(137);">&nbsp;&nbsp;&raquo;&nbsp;&nbsp;</a></td><td>Edward Pierce (Father)</td><td align='right'>100.00</td><td></td><td align='center'>1</td></tr>
<tr><td><a onclick="alert(151);">&nbsp;&nbsp;&raquo;&nbsp;&nbsp;</a></td><td>Jon Steele</td><td align='right'>1,500.00</td><td></td><td align='center'>0</td></tr>
</table>






User codes the `<table...>` and `</table>` tags manually.

<small>end of document</small>
