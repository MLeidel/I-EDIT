<?php 

### SelectListL class
### PUTS A LINK TO ANOTHER PAGE IN THE 1ST COLUMN
// SET A VARIABLE FOR THE SQL SELECT STATEMENT
// SET AN ARRAY VARIABLE FOR THE LIST OF COLUMN NAMES
// $s = "select first_name, last_name, email_addr, rowid from tbldonor where email_addr <> ''";
// "rowid" must be last column named and not included in the $c columns array
// $c = array("First Name","Last Name","Email","!Count","^Amount");
// $tgt = Target page URL for link
// Create new object:
// $slist = new SelectListL($db);
// echo $slist->select($s, $c, $tgt);
///

class SelectListL {

	private $db;
	// arrays for formatting and totals
	private $afmtSL = array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,);
	private $atotSL = array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,);
	private $norows = 0;

	function __construct($dbase) {
		// database object is passed in
		$this->db = $dbase;
	}

	function getTotal($coln) {
		return $this->atotSL[$coln];
	}

	function getNumRows() {
		return $this->norows;
	}

	function getColumns($cols) {
		$tut = "<table border='1' cellpadding='3' cellspacing='0'><tr><td>&nbsp;&nbsp;&nbsp;</td>";	// td for link column
		for($x=0; $x < count($cols); $x++) {
			if (substr($cols[$x],0,1) == "^") {	## decimal
				$this->afmtSL[$x] = 2;
				$cols[$x] = substr($cols[$x],1);
			}
			if (substr($cols[$x],0,1) == "!") {	## integer
				$this->afmtSL[$x] = 1;
				$cols[$x] = substr($cols[$x],1);
			}
			$tut .= "<th>$cols[$x]</th>";
		}
		$tut .= "</tr>\n";
		return $tut;
	}

	function select($sql, $cls, $tgt) {

		// zero out format & totals arrays
		for($x=0; $x < count($this->afmtSL); $x++) {
			$this->afmtSL[$x] = 0;
			$this->atotSL[$x] = 0;
		}

		$tout = $this->getColumns($cls);
		$results = $this->db->query($sql);
		$ar = $results->fetchArray(SQLITE3_NUM);
		if (!$ar) {
			//die("No rows returned");
			return "";
		}

		$cc = count($ar) - 1;

		do {
			$this->norows++;
			$tout .= "<tr><td><a href=\"$tgt?SLSL=$ar[$cc]\">&nbsp;&nbsp;&raquo;&nbsp;&nbsp;</a></td>";
			for($x=0; $x < $cc; $x++) {
				if ($this->afmtSL[$x] == 2) {
					$tout .= "<td align='right'>" . number_format($ar[$x],2) . "</td>";
					$this->atotSL[$x] += $ar[$x];
				} elseif ($this->afmtSL[$x] == 1) {
					$tout .= "<td align='right'>$ar[$x]</td>";
					$this->atotSL[$x] += $ar[$x];
				} else {
					$tout .= "<td>$ar[$x]</td>";
				}
			}
			$tout .= "</tr>\n";

		} while ( $ar = $results->fetchArray(SQLITE3_NUM) );

		$tout .= "</table>";

		return $tout . "<br>";
	}

} // end class SelectListL

?>