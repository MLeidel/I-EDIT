<?php 
/*  Use: include "../inc/tblrows.php"
Helps format data returned as a table.
Formats HTML table ROWS from Array
--------
tblrow(array|csv, String);
tblrow($ar, "<,<,d,>,<");
<   left justify column data
d   format to *.99 and right justify
>   right justify column data
--------
tblhead(String);
tblhead("row1,row2,third,4th");
--------
*/

class Tblrow {
  private $afmt;
  
	function __construct($cols) {
	  // sets the column formats
		$this->afmt = explode( "," , $cols );
	}

  function tblrow($items) {
    if (is_array($items)) {
      $ar = $items;
    } else {
      $ar = explode( ",", $items );  // items was a CSV string
    }
    
    $tbl_row = "<tr><td";
    
    for( $x=0; $x < count($ar); $x++) {
      switch ( trim($this->afmt[$x]) ) {
        case "<":     // left align
          $tbl_row .= ">" . $ar[$x] . "</td>";
          break;
        case ">":     // right align
          $tbl_row .= " align='right'>" . $ar[$x] . "</td>";
          break;
        case "d":     // decimal right align
          if ( is_numeric($ar[$x]) ) {
            $num = number_format($ar[$x], 2);
          } else {
            $num = $ar[$x];
          }
          $tbl_row .= " align='right'>" . $num . "</td>";
          break;
        case "-":     // center in cell
          $tbl_row .= " align='center'>" . $ar[$x] . "</td>";
          break;
      } // end switch
      if ($x === count($ar) - 1) {
        $tbl_row .= "</tr>\n";
      } else {
        $tbl_row .= "<td";
      }
    } // end for
    return $tbl_row;
  } // end function
  
  
  function tblhead($head) {
    $tbl_row = "<tr><th>";
    $ath = explode( "," , $head );
    for( $x=0; $x < count($ath); $x++) {
      $tbl_row .= trim($ath[$x]) . "</th>";
      if ($x === count($ath) - 1) {
        $tbl_row .= "</tr>\n";
      } else {
        $tbl_row .= "<th>";
      }
    } // end for
    return $tbl_row;
  } // end function

} // end class
?>