#Arcgz

`include "libs/Arcgz.php";`

File compression & decompression.

###class: Arcgz

no constructor

```php
$z = new Arcgz();
```
---
###function: putgz(string, string)

Create a compressed .gz file from another file.

Example:
```php
$z->putgz("audit.txt", "audit.gz");
```
---
###function: readgz(string)

Returns the uncompressed contents of a
compressed (gz) file.

Example:
```php
echo $z->readgz("audit.gz");
```
---
###function: putungz(string, string)

Create an uncompressed file from
a compressed (gz) file.

Example:
```php
$z->putungz("audit.gz", "audit.txt");
```
---

<small>end of document</small>

