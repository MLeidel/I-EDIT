#Cryptoo

`include "libs/Cryptoo.php";`

Encryption for Php using Sodium.

###class: Cryptoo

no constructor

```php
$cry = new Cryptoo();
```
---
###function: encrypt(string)

Example:
```php
$enc = $cry->encrypt("text to be encrypted...");
```
---
###function: decrypt(encrypted string)

Example:
```php
$ptext = $cry->decrypt($enc);
```
---
###function: setKey()

`setKey()` creates a key using `sodium_crypto_secretbox_keygen()`.
While your Cryptoo object is instantiated it keeps the key generated with
`setKey()` in memory. If you encrypt **and** decrypt _without using this function_
Cryptoo will use a static pre-generated key. Without using
`setKey()` your text is still encrypted but there is
overall _much less security_ because of the 
unchanging static key. However, in situations where this
may be appropriate you can do encryption without having
to store or transfer a key between object instantiations. 

Example:
```php
$cry->setKey();
```
---
###function: delKey()

zeroes out the Cryptoo key buffer memory

Example:
```php
$cry->delKey();
```
---
###function: exportKey()

After using `setKey()` you can obtain a text version
of the key with this function.

Example:
```php
$key = $cry->exportKey();
```
---
###function: importKey()

Rather than using `setKey()` you can use
this function to import (set) a previously
exported key.

Example:
```php
$cry->importKey($key);
```
---

<small>end of document</small>
