<?php
// security
if ($_COOKIE["valid"] !== "iedit")
  header("location: index.php");

$where = $_POST["cdir"];
$uploaddir = $where . '/';  // eg. 'main/folder/'
$uploadfile = $uploaddir . basename($_FILES['userfile']['name']);
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Image Uploader</title>
</head>
<style type="text/css">
	body {
		margin-left: 50px;
    background: #dddddd;
	}
</style>
<body id="B">
<?Php
echo "<pre style='font: normal 12pt monospace;'>";

if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
		echo "File is valid, and was successfully uploaded.\n";
} else {
		echo "Possible file upload Failure!\n";
}

print_r($_FILES);

echo "\n<a id='A' href='ieditUfile.php?cdir=$where'>Upload Another</a>\n\n";
echo "<pre style='font: normal 9pt monospace;'>\n";

$aFiles = glob($uploaddir . "*.*");
sort($aFiles);

foreach ($aFiles as $filename) {
		echo "$filename size " . filesize($filename) . "\n";
}

?>

</body>
</html>
