/* script1.js (using myJS-1.1.js) */

// on document ready
document.addEventListener("DOMContentLoaded", function(event) { 

	//do work
	gb.bkgs[0] = "../../images/wp1.jpg",
	gb.bkgs[1] = "../../images/wp2.jpg",
	gb.bkgs[2] = "../../images/wp3.jpg",
	gb.bkgs[3] = "../../images/wp4.jpg",
	gb.bkgs[4] = "../../images/wp5.jpg",
	gb.bkgs[5] = "../../images/wp6.jpg",
	gb.bkgs[6] = "../../images/wp7.jpg",
	gb.bkgs[7] = "../../images/wp8.jpg"

	bkgv = JS.getCookie("save_bkg");
	if (bkgv === "") bkgv = "wp6.jpg";
	JS.css('body').background = 'url(' + bkgv + ')';
	JS.css('body').backgroundAttachment = 'fixed';
	JS.css('body').backgroundRepeat = 'no-repeat';

});

	// keep 'globals' in one object
	var gb = {
		buff	: "",
		name	: "",
		spancolor : "<span style='color:black;'>",
		bkgs	: [],
		bkinx : 6
	};

	function changeBkgd() {
		gb.bkinx +=1;
		if (gb.bkinx > 9) {
			gb.bkinx = 0;
		}
		JS.css('body').background = 'url(' + gb.bkgs[gb.bkinx] + ')';
		JS.setCookie("save_bkg", gb.bkgs[gb.bkinx], 30);
	}

/* async stuff goes here (myJS.js) */
/***
JS.webpost("post.php", 1, `onlyfield=${data}`);

function webresponse(n, text) {
	switch (n) {
		case 1:
				JS.htm("#POUT",text);
				break;
		case 2:
				//
				break;
		case 3:
				//
				break;
	}
}
***/

function openrmenu() {
	// uses openav.js and topnav.css
		var x = document.getElementById("myTopnav");
		if (x.className === "topnav") {
				x.className += " responsive";
		} else {
				x.className = "topnav";
		}
}

