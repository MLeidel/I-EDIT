<?php

extract($_POST);

if (isset($U6n7bk_6DTf7)) {
  if (md5($U6n7bk_6DTf7) == "21232f297a57a5a743894a0e4a801fc3") {  // 'admin'
    setcookie("valid", "iedit");
    if ($X == "1")
      header("Location: iedit.php");
    else
      header("Location: iedit2.php");
    exit;
  }
}
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
  <meta charset='UTF-8'>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <title>Log in</title>
  <style>
    input {
    border-radius: 6px 6px 6px 6px;
    -moz-border-radius: 6px 6px 6px 6px;
    -webkit-border-radius: 6px 6px 6px 6px;
    border: 2px solid #000000;
    }
    body {
      margin: 50px;
      font: normal 12pt sans-serif;
      background-image: linear-gradient(bottom, #FFFFFF 0%, #C0C0CC 88%);
      background-image: -o-linear-gradient(bottom, #FFFFFF 0%, #C0C0CC 88%);
      background-image: -moz-linear-gradient(bottom, #FFFFFF 0%, #C0C0CC 88%);
      background-image: -webkit-linear-gradient(bottom, #FFFFFF 0%, #C0C0CC 88%);
      background-image: -ms-linear-gradient(bottom, #FFFFFF 0%, #C0C0CC 88%);
      background-image: -webkit-gradient(
        linear,
        left bottom,
        left top,
        color-stop(0, #FFFFFF),
        color-stop(0.88, #C0C0CC)
      );
      background-repeat: no-repeat;
    }

  </style>
</head>
<body>
<h1>iEdit</h1><h3><?php echo $_SERVER['SERVER_NAME'] ?></h3><br><br>
<form method="post">
  <input type="password" name="U6n7bk_6DTf7" required autofocus>
  <input type="submit" value=" Go ">
  <br><br>

  <input type="radio" id="c1" name="X" value="1"><label for="c1">No Frame</label><br><br>

  <input type="radio" id="c2" name="X" value="2" checked><label for="c2">With Frame</label><br>

</form>
</body>
</html>
