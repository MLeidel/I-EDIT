<?php
// security
if ($_COOKIE["valid"] !== "iedit")
  header("location: index.php");
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset='UTF-8'>
	<meta name='viewport' content='width=device-width, initial-scale=1'>
	<title>I-Edit 2 frame</title>
</head>

<frameset cols="65%,35%">
	<frame name="codeframe" src="iedit.php">
	<frame name="renderframe" id="RDR" src="dummy.html">
</frameset>
