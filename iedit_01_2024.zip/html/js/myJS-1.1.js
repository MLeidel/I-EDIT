/*
	myJS-1.1.js
	May 2018
	Michael D Leidel
*/

var JS = {

	htm : function(qs,val) {
		if (arguments.length === 1) {
			return document.querySelector(qs).innerHTML;
		} else {
			document.querySelector(qs).innerHTML = val;
		}
	},

	doq : function(qs) {
		return document.querySelector(qs);
	},

	css : function(qs, cssx) {
		var m = document.querySelector(qs);
		if (arguments.length === 1) {
			return m.style;
		} else {
			m.style = cssx;
		}
	},

	gss : function(qs, cssx) {
		var m = document.querySelector(qs);
		var prop = window.getComputedStyle(m, null).getPropertyValue(cssx);
		return prop;
	},

	val : function(qs,val) {
		if (arguments.length === 1) {
			return document.querySelector(qs).value;
		} else {
			document.querySelector(qs).value = val;
		}
	},

	tod : function(qs, mode) {
		var m = document.querySelector(qs);
		if (m.style.display === 'none') {
				m.style.display = mode;
		} else {
				m.style.display = 'none';
		}
	},

	show : function(qs, txt) {
			var obj = document.querySelector(qs);
			if (arguments.length > 1) {
				obj.innerHTML = txt;
			}
			obj.style.visibility = "visible";
	},

	hide : function(qs) {
			var obj = document.querySelector(qs);
			obj.style.visibility = "hidden";
	},

	attr : function(qs, aname, avalue) {
		if (arguments.length === 3) {
			document.querySelector(qs).setAttribute(aname, avalue);
		} else {
			return document.querySelector(qs).getAttribute(aname);
		}
	},

	// START ASYNC FUNCTIONS

	webget : function(url, n) {
		fetch(url).then(function(response) {
			return response.text().then(function(text) {
				webresponse(n, text);	// user function to handle response
			});
		});
	},

	webgetjson : function(url, n) {
		fetch(url)
		.then(function(response) {
			return response.json();
		})
		.then(function(jobj) {
			webresponse(n, jobj);	// user function to handle json object
		})
			.catch(function(error) {	
				webresponse(n, "error");	// return "error" instead of json
			});
	},

	webpost : function(url, n, qs) {
		fetch(url, {	
			method: 'post',	
			headers: {	
				"Content-type": "application/x-www-form-urlencoded; charset=UTF-8"	
			},
			body: qs
			})
			.then(function(response) {
				return response.text();
			})
			.then(function (text) {
				webresponse(n, text);	// user function to handle response
			})
			.catch(function (error) {	
				console.log('Request failed', error);	
			});
	},

	websend : function(url, qs) {
		fetch(url, {	
			method: 'post',	
			headers: {	
				"Content-type": "application/x-www-form-urlencoded; charset=UTF-8"	
			},
			body: qs
			})
			.catch(function (error) {	
				console.log('Request failed', error);	
			});
	},

	// START DATE FUNCTIONS

	twoDigitDate : function(n) {
		if (n < 10) 
			return "0" + n;
		else
			return n;
	},

	todayDay : function() {
		// Day of Week Index 0..6
		var d = new Date();
		return d.getDay();
	},

	todayMon : function(bformat) {
		// Returns actual MM number 01..12
		var d = new Date();
		if (arguments.length === 1) {
			return JS.twoDigitDate(d.getMonth() + 1);
		} else {
			return d.getMonth() + 1;
		}
	},

	todayYear : function() {
		var d = new Date();
		return d.getFullYear();
	},

	getMDY : function() {
		var d = new Date();
		var curr_date = JS.twoDigitDate(d.getDate());
		var curr_month = JS.twoDigitDate(d.getMonth() + 1);	//months are zero based
		var curr_year = d.getFullYear();
		return curr_month + "/" + curr_date + "/" + curr_year;
	},

	getYMD : function() {
		var d = new Date();
		var curr_date = JS.twoDigitDate(d.getDate());
		var curr_month = JS.twoDigitDate(d.getMonth() + 1);	//months are zero based
		var curr_year = d.getFullYear();
		return curr_year + "-" + curr_month + "-" + curr_date;
	},

	getHM : function() {
		var d = new Date();
		var curr_Hour = JS.twoDigitDate(d.getHours());
		var curr_Minute = JS.twoDigitDate(d.getMinutes());
		return curr_Hour + ":" + curr_Minute;
	},

	getShortDay : function(n) {
		// Sunday = 0 ...
		var d = new Array('Sun','Mon','Tue','Wed','Thu','Fri','Sat');
		return d[n];
	},

	getLongDay : function(n) {
		var d = new Array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
		return d[n];
	},

	getShortMon : function(n) {
		// January = 0 ...
		var m = new Array('0','Jan','Feb','Mar','Apr','May','Jun','July','Aug','Sep','Oct','Nov','Dec');
		return m[n];
	},

	getLongMon : function(n) {
		// January = 0 ...
		var m = new Array('January','February','March','April','May','June','July','August','Sepember','October','November','December');
		return m[n];
	},

	addDays : function(n) {
		var d = new Date();
		d.setDate(d.getDate() + n);
		return d;
	},

	//	OTHER FUNCTIONS

	sleep : function(milliSeconds) {
		var startTime = new Date().getTime();
		while (new Date().getTime() < startTime + milliSeconds);
	},

	scrollBottom : function() {
		window.scrollTo(0,document.body.scrollHeight);
	},

	rand : function(low, hi) {
		// number between 0 and 9
		return Math.floor((Math.random() * hi) + low);
	},

	getOptionText : function(sid) {
		var obj = document.getElementById(sid);
		return obj.options[obj.selectedIndex].text;
	},

	getOptionIndex : function(sid) {
			var obj = document.getElementById(sid);
			return obj.selectedIndex;
	},

	getQvar : function(v) {
		var query = window.location.search.substring(1);
		var vars = query.split("&");
		for (var i=0;i<vars.length;i++) {
			 var pair = vars[i].split("=");
			 if(pair[0] == v){return pair[1];}
		}
		return(false);
	},

	titleCase : function(str) {
		if ((str===null) || (str===''))
				return false;
		else
				str = str.toString();
	 return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
	},

	/*
	COOKIE FUNCTIONS:
			setCookie( cname, cvalue [, exdays] )
			getCookie( cname )
			deleteCookie( name)

	If exdays (number of days) is not used for setCookie,
	then cookie is deleted when browser is closed.
	*/

	setCookie : function(cname, cvalue, exdays) {
					var d = new Date();
					d.setTime(d.getTime() + (exdays*24*60*60*1000));
					var expires = "expires="+d.toUTCString();
			if (exdays)
					document.cookie = cname + "=" + cvalue + "; " + expires;
			else
					document.cookie = cname + "=" + cvalue;
	},

	getCookie : function(cname) {
		var name = cname + "=";
		var ca = document.cookie.split(';');
		for(var i=0; i<ca.length; i++) {
						var c = ca[i];
						while (c.charAt(0)==' ') c = c.substring(1);
						if (c.indexOf(name) != -1) 
							return c.substring(name.length, c.length);
		}
		return "";
	},

	deleteCookie : function(name) {
		JS.setCookie(name,"",-1);
	}

};
