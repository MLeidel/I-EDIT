
/*
COOKIE FUNCTIONS:
	setCookie( cname, cvalue [, exdays] )
	getCookie( cname )
	deleteCookie( name)

If exdays (number of days) is not used for setCookie,
then cookie is deleted when browser is closed.
*/
function setCookie(cname, cvalue, exdays) {
		var d = new Date();
		d.setTime(d.getTime() + (exdays*24*60*60*1000));
		var expires = "expires="+d.toUTCString();
	if (exdays)
		document.cookie = cname + "=" + cvalue + "; " + expires;
	else
		document.cookie = cname + "=" + cvalue;
}

function getCookie(cname) {
		var name = cname + "=";
		var ca = document.cookie.split(';');
		for(var i=0; i<ca.length; i++) {
				var c = ca[i];
				while (c.charAt(0)==' ') c = c.substring(1);
				if (c.indexOf(name) != -1) return c.substring(name.length, c.length);
		}
		return "";
}

function deleteCookie(name) {
		setCookie(name,"",-1);
}
/// END COOKIE FUNCTIONS ///

