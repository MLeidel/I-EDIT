<?php
// security
if ($_COOKIE["valid"] !== "iedit")
  header("location: index.php");
?>
<!DOCTYPE html> <!-- Perhaps build some security for access to these pages or not -->
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>I-Edit</title>

	<!--<link href='https://fonts.googleapis.com/css?family=Roboto+Mono:400' rel='stylesheet' type='text/css'>-->
	<!--<link href='https://fonts.googleapis.com/css?family=Droid+Sans+Mono' rel='stylesheet' type='text/css'>-->
	<!--<link href='https://fonts.googleapis.com/css?family=PT+Mono' rel='stylesheet' type='text/css'>-->
	<!--<link href='https://fonts.googleapis.com/css?family=Oxygen+Mono' rel='stylesheet' type='text/css'>-->
	<!--<link href="https://fonts.googleapis.com/css2?family=Source+Code+Pro" rel="stylesheet" type='text/css'>-->
	<!--<link href="https://fonts.googleapis.com/css2?family=Fira+Code&display=swap" rel="stylesheet">-->

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono&display=swap" rel="stylesheet">

  <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.2.6/ace.js"
      type="text/javascript" charset="utf-8"></script>
  <script src="js/myJS-1.2.min.js"></script>
  <script src="config/tags.js" defer></script>

      <!--

      WARNING !!   WARNING !!   WARNING !!

      THIS IS THE I-Edit MAIN APPLICATION CODE FILE

      USE EXTREME CAUTION WHEN MAKING CHANGES !

      This source uses 'ace.js' software
      https://github.com/ajaxorg/ace/blob/master/LICENSE
      Copyright (c) 2010, Ajax.org B.V.
      All rights reserved.

      -->

<style>

	#editor {
		position: absolute;
		top: 66px;
		right: 0;
		bottom: 0;
		left: 0;

		/* FONT STYLING */
		/*font-family: 'Roboto Mono';*/
		/*font-family: 'Droid Sans Mono';*/
		/*font-family: 'PT Mono';*/
		/*font-family: 'Source Code Pro';*/
		/*font-family: 'DejaVu Sans Mono', 'Liberation Mono', monospace;*/

    font-family: 'JetBrains Mono', monospace;

		font-size: 10pt;
		border-top: 1px solid gray;
	}

  #HDR {
    background-image: url(images/0.jpg);
    padding: 4px;
    height: 100px;
  }

  #TOOLS {
    display: none;
    height: 32px; /* 36 */
  }

  body {
    margin: 0px;
    background: #333333;
    font-family: sans-serif;
    font-size: 10pt;
  }

  /* ----------------------------------------- */

  :root {
    --selected: #000; /* color for checkbox/radio selected */
    --unselected: #999; /* color for checkbox/radio unselected */
    --button-bkg: #BBB; /* button background color */
    --button-clr: black; /* button text color */
    --button-hov: green; /* button hover text color */
    --button-rad: 2px; /* button corner radius */
    --borders: #ccc; /*text, textarea, select border color */
  }

  /* ----------------------------------------- */

  input[type=checkbox] {
    zoom: 1.5;
    vertical-align: middle;
  }

  input[type=radio] {
    zoom: 1.2;
   vertical-align: middle;
  }

  input[type=checkbox] + label,
  input[type=radio] + label {
    color: var(--unselected);
    font-style: italic;
  }

  input[type=checkbox]:checked + label,
  input[type=radio]:checked + label {
    color: var(--selected);
    font-style: normal;
  }

  label {
      /* zoom: 1.5; */  /* make all bigger or smaller */
      vertical-align: middle;
  }

  /* ----------------------------------------- */

  input[type=button],
  input[type=submit] {
    background-color: var(--button-bkg);
    border: none;
    color: var(--button-clr);
    padding: 2px 5px;
    text-align: center;
    display: inline-block;
    font-size: inherit;
    margin: 2px 2px;
    cursor: pointer;
    border-radius: var(--button-rad);
  }

  input[type=button]:enabled:hover,
  input[type=submit]:enabled:hover {
    color: var(--button-hov);
  }

  input[type=button]:disabled,
  input[type=submit]:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }

  a:hover {
    text-decoration: none;
    background: var(--button-bkg);
    color: var(--button-hov);
  }

  input[type=text],
  input[type=date],
  input[type=search],
  input[type=email],
  input[type=tel],
  input[type=number],
  input[type=password],
  input[type=color]
  {
   vertical-align: middle;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  -box-sizing: border-box;
  padding:2px;
  font-size: inherit;
  margin: 4px 2px;
  border: thin solid var(--borders);
  }

  textarea, select, fieldset, table, th, td {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  -box-sizing: border-box;
  padding:2px;
  font-size: inherit;
  margin: 2px 2px;
  border: thin solid var(--borders);
  }

  iframe {
      overflow:hidden;
  }

  @-webkit-keyframes slide-down {
      0% { opacity: 0; -webkit-transform: translateY(-100%); }
    100% { opacity: 1; -webkit-transform: translateY(0); }
  }
  @-moz-keyframes slide-down {
      0% { opacity: 0; -moz-transform: translateY(-100%); }
    100% { opacity: 1; -moz-transform: translateY(0); }
  }

/* Background class for JSmodal */
.JSmodal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 2; /* Sit on top */
  padding-top: 200px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* JSmodal Content */
.JSmodal-content {
  position: relative;
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 40%;
  border-radius: 5px;
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
  -webkit-animation-name: animatetop;
  -webkit-animation-duration: 0.4s;
  animation-name: animatetop;
  animation-duration: 0.4s
}

/* JSmodal Add Animation */
@-webkit-keyframes animatetop {
  from {top:-300px; opacity:0}
  to {top:0; opacity:1}
}

@keyframes animatetop {
  from {top:-300px; opacity:0}
  to {top:0; opacity:1}
}

/* JSmodal The Close Button */
.JSclose {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}
.JSclose:hover,
.JSclose:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}

#flashMessage {
  display: none;
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: rgba(0, 0, 0, 0.8);
  color: white;
  padding: 16px 24px;
  border-radius: 8px;
  font-family: Arial, sans-serif;
  font-size: 18px;
  z-index: 9999;
}

</style>

</head>
<body onunload="setLastFile()">
<iframe src="ieditTools.html" height="28" width="100%" id="TOOLS" frameborder="0" scrolling="no">
</iframe>
<div id="HDR" style="text-align:center;width=100%;" ondblclick="changeBg(event)">

  <div id="flashMessage"></div>

  <input type="button" onclick="toggleTools()" value="Tools" title="Toggle tools menu (Esc)">&nbsp;

  <input type="text" id="DAN" value="." style="text-align:right;width:12em;" readonly>
  <input type="button" onclick="listAction('⇑');" value=" &uArr; " onmouseover="this.focus()">
  <a id="LST"></a>
  <input type="text" id="FILN" placeholder="file" style="width:12em;" title="/ dir, + clone, < copy, - min, ! delBU">
  <input type="button" id="REFR" title="Refresh" onclick="location.reload()" value="R">
  <br>
  <input type="color" id="CLR" onclick="colorpick()" value="#999999" title="#999999"
    style="height: 18px;" onmouseenter="this.title = this.value">&nbsp;&nbsp;
  <img src="images/cloud_upload_white.png" align="top" onclick="upLoadFile();" title="upload local file">&nbsp;&nbsp;
  <img src="images/download.jpg" align="top" onclick="downloadFile();" title="download current file">&nbsp;&nbsp;
  <a href="https://gemini.google.com" target="_blank">
    <img src="images/gemi.png" align="top" title="Google Gemini"></a>&nbsp;&nbsp;
	<input type="button" onclick="launchClips()" value="Clips" title="code & links - Alt-c">&nbsp;&nbsp;
	<!--<input type="button" onclick="goDoc()" value="md" title="Markdown Docments">-->
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="button" onclick="putFile()" id="SBUT" value="Save" title="Ctrl-s">&nbsp;
	<input type="button" onclick="delFile()" value="Delete" title="blank file delete folder">&nbsp;
	<input type="button" onclick="scratchpad()" value="Pad" title="Scratch pad to hold text">&nbsp;
	<input type="button" onclick="renderPage()" value=" Render " title="Render Page (Ctrl-r)">
</div>

<div id="JSmodal" class="JSmodal">
  <div class="JSmodal-content">
    <span class="JSclose" onclick="JSmodal.close();">&#65336;</span>
    <p></p>
  </div>
</div>

<div id="editor">container for Ace Editor... If you see this, there is probably an error in your Javascript code.
</div>

<!--		 ############## JS Starts Here ##################			-->

<script type="text/javascript">
/*jshint -W097 */
/*jshint esversion: 6 */
/* globals JS: false */
/* globals ace: false */
/* globals atags: false */

"use strict";

	let gvar = {
		dname : ".",
		fname : "",
		rwin : null,
		zenw : "",
		saveButton : null,
		bTools : false,
    bkinx : 0,
    sall : false,
    bmk_inx: 0,
    bookmarks: [],   // array of row numbers
    maxBookmarks: 50
	};

  let bkgs = [];
  bkgs[0] = "images/0.jpg";
  bkgs[1] = "images/2.jpg";
  bkgs[2] = "images/3.jpg";
  bkgs[3] = "images/4.jpg";
  bkgs[4] = "images/5.jpg";

  // set selected HDR image
  let bkgv = JS.getCookie("save_ieditbg");
  if (bkgv === "") bkgv = "images/0.jpg";
  JS.css('#HDR').background = 'url(' + bkgv + ')';
  // JS.css('#HDR').background-size = 'contain';

/////// ACE STUFF SETUP //////////
  let editor = ace.edit("editor");

	// ACE CONFIGURE
	editor.$blockScrolling = Infinity;	// ace debug suggestion
	editor.setShowPrintMargin(false);
	editor.setHighlightActiveLine(false);
	editor.session.setTabSize(2);
  // SEE CSS #editor FOR FONT STYLING //

///////// ADD (ACE) CUSTOM HOT KEYS //////////
	editor.commands.addCommand({
			name: 'htmlBreak',
			bindKey: {win: 'Ctrl-Enter', mac: 'Command-Enter'},
			exec: function(editor) {
					editor.insert("<br>");
			},
			readOnly: false // Do NOT apply this command in readOnly mode
	});
	editor.commands.addCommand({
			name: 'saveFile',
			bindKey: {win: 'Ctrl-s', mac: 'Command-s'},
			exec: function(editor) {
					putFile();
			},
			readOnly: false
	});
	editor.commands.addCommand({
			name: 'htmlNbsp',
			bindKey: {win: 'Ctrl-Space', mac: 'Command-Space'},
			exec: function(editor) {
					editor.insert("&nbsp;");
			},
			readOnly: false
	});
	editor.commands.addCommand({
			name: 'expandSelected',
			bindKey: {win: 'Alt-z',	mac: 'Alt-z'},
			exec: function(editor) {
					zentag();
			},
			readOnly: false
	});
	editor.commands.addCommand({
			name: 'wrapSelected',
			bindKey: {win: 'Alt-a',	mac: 'Alt-a'},
			exec: function(editor) {
					zentaga(false);
			},
			readOnly: false
	});
	editor.commands.addCommand({
			name: 'WrapSelAgain',
			bindKey: {win: 'Alt-w',	mac: 'Alt-w'},
			exec: function(editor) {
					zentaga(true);
			},
			readOnly: false
	});
	editor.commands.addCommand({
			name: 'render',
			bindKey: {win: 'Ctrl-r', mac: 'Command-r'},
			exec: function(editor) {
					renderPage();
			},
			readOnly: false
	});
	editor.commands.addCommand({
			name: 'ieditHelp',
			bindKey: {win: 'Alt-h',	mac: 'Alt-h'},
			exec: function(editor) {
					launchHelp();
			},
			readOnly: false
	});
	editor.commands.addCommand({
			name: 'viewTagsJS',
			bindKey: {win: 'Alt-x',	mac: 'Alt-x'},
			exec: function(editor) {
					viewZenTags();
			},
			readOnly: false
	});
	editor.commands.addCommand({
			name: 'launchclips',
			bindKey: {win: 'Alt-c',	mac: 'Alt-c'},
			exec: function(editor) {
					launchClips();
			},
			readOnly: false
	});
  editor.commands.addCommand({
          name: 'insertDate',
          bindKey: {win: 'Alt-t', mac: 'Alt-t'},
          exec: function(editor) {
              editor.insert(JS.getMDY());
          },
          readOnly: false
  });
  editor.commands.addCommand({
          name: 'toggleTools',
          bindKey: {win: 'Esc', mac: 'Esc'},
          exec: function(editor) {
              toggleTools();
          },
          readOnly: false
  });
  editor.commands.addCommand({
          name: 'InsertColor',
          bindKey: {win: 'Alt-i', mac: 'Alt-i'},
          exec: function(editor) {
              editor.insert(JS.val("#CLR"));
          },
          readOnly: false
  });
  editor.commands.addCommand({
          name: 'openConfigTags',
          bindKey: {win: 'Alt-u', mac: 'Alt-u'},
          exec: function(editor) {
            JS.setCookie( "ieditLastFile", "config" + "," + "tags.js", 30);
            open("iedit.php");
          },
          readOnly: false
  });
  editor.commands.addCommand({
          name: 'openNewFullTab',
          bindKey: {win: 'Alt-n', mac: 'Alt-n'},
          exec: function(editor) {
            JS.setCookie( "ieditLastFile", gvar.dname + ",", 30);  // blank filename
            open("iedit.php");
          },
          readOnly: false
  });
  editor.commands.addCommand({
          name: 'openNewHalfTab',
          bindKey: {win: 'Ctrl-Alt-n', mac: 'Command-Alt-n'},
          exec: function(editor) {
            JS.setCookie( "ieditLastFile", gvar.dname + ",", 30);  // blank filename
            open("iedit2.php");
          },
          readOnly: false
  });
  // add command to lazy-load keybinding_menu extension
  editor.commands.addCommand({
      name: "showAllKBshortcuts",
      bindKey: {win: "Ctrl-Alt-h", mac: "Command-Alt-h"},
      exec: function(editor) {
          ace.config.loadModule("ace/ext/keybinding_menu", function(module) {
              module.init(editor);
              editor.showKeyboardShortcuts();
          });
      }
  });
  editor.commands.addCommand({
          name: 'ScratchPad',
          bindKey: {win: 'Ctrl-Shift-s', mac: 'Command-Shift-s'},
          exec: function(editor) {
              scratchpad();
          },
          readOnly: false
  });

////////////////////////////// Book Marks //////////////////////////////

// Add/remove bookmark marker in gutter
function renderBookmarks(editor) {
    // Remove old bookmark markers
    // If you use only one custom class, this is enough:
    editor.session.setAnnotations([]);

    // Clear any existing bookmark markers we created
    if (gvar.bookmarkMarkerIds) {
        gvar.bookmarkMarkerIds.forEach(function(id) {
            editor.session.removeMarker(id);
        });
    }
    gvar.bookmarkMarkerIds = [];

    // // Add gutter markers for each bookmark
    // gvar.bookmarks.forEach(function(row) {
    //     var range = new ace.Range(row, 0, row, 1);
    //     var markerId = editor.session.addMarker(
    //         range,
    //         "ace_bookmark-marker",
    //         "fullLine"
    //     );
    //     gvar.bookmarkMarkerIds.push(markerId);
    // });
}

// Toggle bookmark on Ctrl+click in gutter
editor.on("guttermousedown", function(e) {
    if (!e.domEvent.ctrlKey) return;

    var row = e.getDocumentPosition().row;
    var index = gvar.bookmarks.indexOf(row);

    if (index === -1) {
        // Add bookmark
        gvar.bookmarks.unshift(row);

        if (gvar.bookmarks.length > gvar.maxBookmarks) {
            gvar.bookmarks.pop();
        }
        flashMessage('Bookmark Set', 500)
    } else {
        // Remove bookmark
        gvar.bookmarks.splice(index, 1);

        // Keep navigation index valid
        if (gvar.bmk_inx >= gvar.bookmarks.length) {
            gvar.bmk_inx = 0;
        }
        flashMessage('Bookmark Removed', 500)
    }

    renderBookmarks(editor);
    e.stop();
});


// Go to next bookmark
editor.commands.addCommand({
    name: "Goto Bookmark",
    bindKey: { win: "F3", mac: "F3" },
    exec: function(editor) {
        if (gvar.bookmarks.length === 0) return;

        gvar.bmk_inx++;
        if (gvar.bmk_inx >= gvar.bookmarks.length) {
            gvar.bmk_inx = 0;
        }

        editor.gotoLine(gvar.bookmarks[gvar.bmk_inx] + 1, 0, true);
    },
    readOnly: false
});

// Clear all bookmarks
editor.commands.addCommand({
    name: "Clear Bookmarks",
    bindKey: { win: "Shift-F3", mac: "Shift-F3" },
    exec: function(editor) {
        if (confirm("Clear Bookmarks")) {
            gvar.bookmarks = [];
            gvar.bmk_inx = 0;
            renderBookmarks(editor);
        }
    },
    readOnly: false
});


////////// END ACE SETUP STUFF //////////////

	JS.tod("#TOOLS","block");
	gvar.saveButton = JS.doq("#SBUT");

  function toggleTools() {
    if (gvar.bTools == false) {
      JS.css("#TOOLS").display = 'block';
      JS.css("#TOOLS").animation = "slide-down 1s ease";
      gvar.bTools = true;
    } else {
      JS.css("#TOOLS").display = 'none';
     gvar.bTools = false;
    }
  }

  /*
      FUNCTIONS FOR FILE HANDLING AT LOAD AND UNLOAD TIMES
  */
	function setLastFile() {
		JS.setCookie( "ieditLastFile", gvar.dname + "," + gvar.fname, 30);
	}
	function getLastFile() {
		let avals;
		let pathvals = JS.getCookie("ieditLastFile");
		if (pathvals !== "") {  // if no cookie take defaults
			avals = pathvals.split(",");
			gvar.dname = avals[0];  // dir name
			gvar.fname = avals[1]; // file name
		}
		JS.val("#DAN", gvar.dname);    // both form fields will be empty on startup
		JS.val("#FILN", gvar.fname);  // so this sets them
		// the following opens the file into the editor
		JS.webpost("ieditHand.php", 1, `key=R&fna=${gvar.fname}&cpath=${gvar.dname}`);
		// the following loads the form select for the correct directory
		JS.webpost("ieditHand.php", 2, `key=CD&fna=gvar.fname&cpath=${gvar.dname}`);
	}

	getLastFile();


  /***
        THIS FUNCTION PROCESSES THE "ASYNC" RESPONSES
  ***/

	function webresponse(n, text) {
		switch(n) {
			case 1:
				//// PUT FILE CONTENTS TO ACE EDITOR
				/* discontinued check for APND not used much

        // Also check for APND to current file
        let obj = JS.doq("#APND");
        if (obj.checked) {
          let txt = editor.getValue();
          txt = txt + "\n" + text;    // append the selected file contents
          editor.setValue(txt, -1);
          obj.checked = false;        // turn off the check flag!
          gvar.fname = JS.val('#FILN');   // reset this global to current file name
          editor.focus();
          editor.clearSelection();
          JSmodal.open(1, gvar.fname + " was appended.");
          break;
        }
        */
				setFileMode();
				editor.setValue(text, -1);
				JS.val("#FILN", gvar.fname);
				gvar.saveButton.disabled = editor.getSession().setUndoManager(new ace.UndoManager());
				editor.clearSelection();
				// set the page title
    		if (parent.frames.renderframe === undefined) {
          document.title = "☐" + gvar.fname;

    		} else {  // renderframe is present
    			window.parent.document.title = "☐☐" + gvar.fname;
    		}
				editor.focus();
				/*
				if the loaded page contains this text "AUTORENDER"
				anywhere, then the page is rendered immediately after loading.
				It is usually placed in a code comment.
				*/
				if (gvar.fname == "index.php" || gvar.fname == "index.html" || gvar.fname.endsWith(".md")) {
          if (text.indexOf("AUTORENDER") > 0) {
            renderPage();
          }
				}
				break;
			case 2:
				//// UPDATE THE FORM SELECT LIST
				JS.htm("#LST", text);
        editor.focus();
        if (gvar.sall === true) {
          gvar.sall = false;
          editor.selectAll();    // indicates active file has left its 'home' directory
          JS.val("#FILN", "");  // must enter filename to save current or load new fiie
        }
				break;
			case 3:
				//// SAVE ACE EDITOR TO FILE
				if (text !== "Success") JSmodal.open(0,"Something went wrong");
				getFileList();
				// file was saved reset 'Save' button and UndoManager
				editor.session.getUndoManager().markClean();
				gvar.saveButton.disabled = editor.session.getUndoManager().isClean();
        editor.focus();
        if (gvar.save !== "") { // This was Save a Selection?
          JS.val("#FILN", gvar.save); // swap back the current file name
          gvar.save = ""; // reset the save field
        }
				break;
      case 4:
        //// CLONE DIRECTORY CONTENTS
        JS.val("#FILN", "");
        getFileList();
        JSmodal.open(1, text);
        editor.focus();
        break;
			case 5:
				//// DELETE FILE OR DIR
        if (text === "Failed") {
            JSmodal.open(0, "delete failed");
            return;
        }
				editor.setValue("Delete Succeeded");
				if (gvar.fname === "") {
					gvar.dname = ".";
					JS.val("#DAN",".");
				}
				getFileList();
				JS.val("#FILN", "");
        editor.focus();
        gvar.saveButton.disabled = editor.getSession().setUndoManager(new ace.UndoManager());
				break;
			case 6:
				//// NEW DIRECTORY
				if (text === "Failed") {
					JSmodal.open(0, "Fail: New Dir");
          JS.val("#FILN", "");
          editor.setValue("new directory NOT created", -1);
				}	else {
					getFileList();
					JS.val("#FILN", "");
          editor.setValue("new directory created", -1);
				}
        editor.focus();
        gvar.saveButton.disabled = editor.getSession().setUndoManager(new ace.UndoManager());
				break;
      case 7:
        //// COPY FILE
        if (text === "Success") {
            getFileList();
            JS.val("#FILN", "");
            editor.setValue("copy succeeded", -1);
        } else {
            JSmodal.open(0, "Fail: file copy");
            editor.setValue("copy failed !", -1);
        }
        editor.focus();
        gvar.saveButton.disabled = editor.getSession().setUndoManager(new ace.UndoManager());
        break;
      case 8:
        //// MINIFICATION
        getFileList();
        JS.val("#FILN", "");
        JSmodal.open(1, "created " + text);
        editor.focus();
        break;
      case 9:
        //// display scratch pad text in popup
        let padform = `
        <textarea id='TAS' rows='16' style='width: 100%;padding: 6px;' wrap='off'>${text}</textarea>
        <br><br>
        <input type='button' onclick='scratchSave()' value='Save'><br>`;
	      JSmodal.open(0,padform);
	      JS.doq("#TAS").focus();
        break;
		} // end switch
	}  // end function
////


	function getFileList() {
		JS.webpost("ieditHand.php", 2, `key=CD&fna=${gvar.fname}&cpath=${gvar.dname}`);
	}

/***
      HANDLES USER SELECTION OF FILES TO LOAD
      AND CHANGING DIRECTORIES
***/

  function open_index_page() {
    gvar.fname = "index.php";
    name = "index.php";
    JS.webpost("ieditHand.php", 1, `key=R&fna=${name}&cpath=${gvar.dname}`);
  }

  function listAction(name) {
    let dna, inx;
    let gfile = [".png",".jpg",".jpeg",".gif",".bmp",".pdf",".tiff",".svg",".webp",".ico",".exif"];
    let gext = name.toLowerCase().substring(name.lastIndexOf("."));
    if (gvar.saveButton.disabled === false) {  //
      JSmodal.confirm(`
        gvar.saveButton.disabled = true;
        JSmodal.close();
        listAction('${name}');`,
        "Current File Not Saved...\nContinue?");
      return;
    }
    // redirect a graphic file to new plain browser tab for viewing
    if (gfile.includes(gext)) {
      open(gvar.dname + "/" + name);
      return;
    }
    // process commands from the 'file input field'
    if (name.startsWith("⇓")) { // move to selected directory
      dna = name.substring(1);
      if (gvar.dname == ".") {
        gvar.dname = dna;
      } else {
        gvar.dname += "/" + dna;
      }
      JS.val("#DAN", gvar.dname);
      gvar.sall = true;
      // change directories
      JS.webpost("ieditHand.php", 2, `key=CD&cpath=${gvar.dname}`);

      open_index_page();

      // if (gvar.dname.indexOf("/") < 0) { // don't ask if a /subdirectory
    		// JSmodal.confirm(`
      //     open_index_page();
    		//   JSmodal.close();`,
    		//   "Open index.php?");
      // }

    } else {
      if (name == "⇑") {  // Move back one directory
        inx = gvar.dname.lastIndexOf("/");
        if (inx == -1) {
          gvar.dname = ".";
        } else {
          gvar.dname = gvar.dname.slice(0, inx);
        }
        JS.val("#DAN", gvar.dname);
        gvar.sall = true;
        JS.webpost("ieditHand.php", 2, `key=CD&cpath=${gvar.dname}`);
      } else {
        // open selected file
        gvar.fname = name;
        JS.webpost("ieditHand.php", 1, `key=R&fna=${name}&cpath=${gvar.dname}`);
      }
    }
  }

  /***
        SET AN 'ACE' THEME BASED ON FILE EXTENTION
        https://github.com/ajaxorg/ace/tree/master/lib/ace/theme
  ***/

	function setFileMode() {
	  let ext;
		ext = gvar.fname.substring( gvar.fname.lastIndexOf(".") + 1 );
		switch(ext) {
			case "js":
				editor.session.setMode("ace/mode/javascript");
				editor.setTheme("ace/theme/tomorrow_night"); // tomorrow_night_eighties twilight
				break;
			case "php":
				editor.session.setMode("ace/mode/php");
				editor.setTheme("ace/theme/twilight"); // monokai cobalt vibrant_ink clouds_midnight kr_theme
				break;
			case "html":
				editor.session.setMode("ace/mode/html"); // solarized_light textmate tomorrow_night
				editor.setTheme("ace/theme/twilight");
				break;
			case "css":
				editor.session.setMode("ace/mode/css"); // solarized_light
				editor.setTheme("ace/theme/solarized_dark");
				break;
      case "md":
        editor.session.setMode("ace/mode/markdown");
        editor.setTheme("ace/theme/twilight");
        break;
      case "json":
        editor.session.setMode("ace/mode/javascript");
        editor.setTheme("ace/theme/tomorrow_night_eighties");
        break;
      case "py":
        editor.session.setMode("ace/mode/python");
        editor.setTheme("ace/theme/twilight");
        break;
			default:
				editor.session.setMode("ace/mode/text");
				editor.setTheme("ace/theme/textmate");
		}
	}

/***
    DELETE THE CURRENT FILE
***/

	function delFile() {
		gvar.fname = JS.val("#FILN");
		JSmodal.confirm(`
		  JS.webpost('ieditHand.php', 5, \`key=X&fna=${gvar.fname}&cpath=${gvar.dname}\`);
		  JSmodal.close();`,
		  "Delete: "+gvar.dname+"/"+gvar.fname+" ?");
	}

/***
    SET COLORPICKER TO INTIAL SELECTED VALUE
***/

  function colorpick() {
    let selclr = editor.getSelectedText();
    if (selclr !== "") {
      if (selclr.length === 6)
        selclr = "#" + selclr;
      if (selclr.length === 7)
        JS.val("#CLR", selclr);
    }
    editor.focus();
  }

/***
    SAVE THE CURRENT FILE AND OTHER OPERATIONS
***/

	function putFile() {
		let txt = editor.getValue();
		let dn = JS.val("#FILN");
		if (dn.startsWith("/")) {   // make directory
			dn = dn.substring(1);
			makeDirectory(dn);
            editor.focus();
			return;
		}
    if (dn.startsWith("+")) {   // clone directory
      dn = dn.substring(1);
      JSmodal.confirm(`
        cloneDir('${dn}');
        editor.focus();`,
        "clone " + dn + " from " + gvar.dname);
      return;
    }
    if (dn.startsWith("<")) {   // copy a file to cur directory
      dn = dn.substring(1);  // Note: dn is a fullpath (filename)
      JSmodal.confirm(`
        copyFile('${dn}');
        JSmodal.close();
        editor.focus();`,
        "copy " + dn + " to " + gvar.dname);
      return;
    }
    if (dn.startsWith("-")) {   // request JS minification
      let file = "";
      file = dn.substring(1);
      if (file === null) {
          return;
      }
      if (!file.endsWith(".js")) {
          JSmodal.open(0, "NOT JAVASCRIPT FILE");
          return;
      }
      JSmodal.confirm(`
        JS.webpost('ieditHand.php', 8, \`key=MN&cpath=${gvar.dname}&fna=${file}\`);
        JSmodal.close();
        editor.focus();`,
        "minifiy " + file + " ?");
      return;
    }
    if (dn == "!") {  // Remove bu_ backups for current directory
      JS.websend("ieditHand.php", `key=BU&cpath=${gvar.dname}`);
      JS.sleep( 2000 ); // wait 2 seconds
      location.reload();  // refresh the file list
      return;
    }

    // these 10 lines strip whitespace at EOL - comment out if you don't want this.
    if (!dn.endsWith(".md")) {  // NEVER FOR MARKDOWN FILES !!
      editor.find('[ \t]+$',{
          backwards: false,
          wrap: true,
          caseSensitive: false,
          wholeWord: false,
          regExp: true
      });
      editor.replaceAll('');
    }

    // send text and file info to handler
		txt = encodeURIComponent(txt);
		gvar.fname = JS.val("#FILN");
		JS.webpost("ieditHand.php", 3,
            `key=W&fna=${gvar.fname}&cpath=${gvar.dname}&txt=${txt}`);
	}


/***
    Pop Text Pad for Temp Save of text
***/

	function scratchpad() {
	  JS.webget("scratch.txt", 9);
	}
	function scratchSave() {
	  let text2save = JS.val("#TAS");
	  text2save = encodeURIComponent(text2save);
	  JS.websend("ieditHand.php", `key=SS&txt=${text2save}`);
	  JSmodal.close();
	}
  JS.doq("#JSmodal").onkeydown = function(evt) {
      evt = evt || window.event;
      if(evt.key === "Escape") {
          JSmodal.close();
      }
  };

/***
    CREATE A NEW FOLDER (DIRECTORY) IN THE CURRENT DIRECTORY
***/

	function makeDirectory(newdir) {
		if (newdir === null) {
			return;
	  }
		JS.webpost("ieditHand.php", 6, `key=N&cpath=${gvar.dname}&fna=${newdir}`);
	}

/***
    COPY THIS DIRECTORY'S CONTENTS INTO A NEW DIRECTORY
***/
  function cloneDir(newdir) {
      if (newdir === null) {
          return;
      }
      JS.webpost("ieditHand.php", 4, `key=K&cpath=${gvar.dname}&fna=${newdir}`);
  }

/***
    COPY'S FILE INTO THE CURRENT DIRECTORY
***/

  function copyFile(file) {
    if (file === null) {
        return;
    }
    JS.webpost("ieditHand.php", 7, `key=CP&cpath=${gvar.dname}&fna=${file}`);
  }

  /***
      PERFORMED WHEN 'RUN' BUTTON IS CLICKED OR 'CTRL-R'
      FILE IS RENDERED IN THE RIGHT HAND FRAME OR SEPARATE TAB
  ***/

	function renderPage() {
    let fileoutname = "";
    let inx = 0;

    //  select correct file name to render
    inx = gvar.fname.lastIndexOf(".md");
    if (inx === -1) {
        fileoutname = gvar.fname;
    } else {
        fileoutname = gvar.fname.slice(0, inx) + ".html";
    }
    //console.debug(fileoutname);
    // save before rendering
    putFile();
    JS.sleep( 1100 );

		if (parent.frames.renderframe === undefined) {
			if ( (gvar.rwin === null) || (gvar.rwin === undefined) || (gvar.rwin.closed === true) ) {
				gvar.rwin = window.open(gvar.dname+"/"+fileoutname, "_blank");
			}
			else {
				gvar.rwin.location = gvar.dname+"/"+fileoutname;    // reuse tab
			}
		} else {  // renderframe is present
			parent.frames.renderframe.location = gvar.dname+"/"+fileoutname;
		}

    editor.focus();
	}

  /***
      INSERTS THE SELECTED KEY WORD REPLACING IT WITH THE EXPANDED CODE
      OR IF NOT A KEY MAKING HTML TAGS
  ***/

function zentag() {
  let wsp = [9,10,32, NaN];  // tab, LF, space
  let inx = 0;
  let code = 0;
  let txtbuf = "";
  let targ = "";
  inx = editor.session.doc.positionToIndex(editor.selection.getCursor());
  txtbuf = editor.getValue();
  code = txtbuf.charCodeAt(inx);
  if (!wsp.includes(code)) return;  // must be at right whitespace boundary
  inx -= 1;
  if (inx < 0) return;
  code = txtbuf.charCodeAt(inx);
  while (!wsp.includes(code)) {
    targ = String.fromCharCode(code) + targ;
    inx -= 1;
    if (inx >= 0)
      code = txtbuf.charCodeAt(inx);
    else
      break;
  }
  // targ should contain the key to look for
  editor.removeWordLeft();  // remove the key work in the editor
  if (atags[targ] !== undefined) {
    editor.insert(atags[targ]);  // targ is a valid key value
  } else {  // stag not a valid key value
    editor.insert("<" + targ + "></" + targ + ">");
  }
}


function flashMessage(text, duration = 1000) {
  const el = document.getElementById('flashMessage');
  el.textContent = text;
  el.style.display = 'block';

  clearTimeout(el._hideTimeout);
  el._hideTimeout = setTimeout(() => {
    el.style.display = 'none';
  }, duration);
}

  /***
      POP-UP DISPLAYING ALL OF THE 'ZEN' TAGS AVAILABLE
  ***/

  function viewZenTags() {
    let str_atags = "ZEN TAGS:\n";
    Object.keys(atags).forEach(function(key) {
      str_atags += key + " • ";
    });
    JSmodal.open(1, str_atags);
  }

  /***
      RUN WHEN CTRL-A IS PRESSED
      PROMPTS FOR A TAG AND THEN ENCLOSES SELECTED TEXT WITH IT.
      CTRL-W REPEATS THE PREVIOUS CTRL-A ACTION.
      This function can be expanded to perform a variety of
      useful operations using the switch/case structure.
      IF NO SELECTION USER IS PROMPTED FOR KEY WORD FOR
      CODE INSERTION.

  ***/
	function zentaga(t) {
		let stxt = "";
		let stag = null;
		stxt = editor.getSelectedText();

		// is it Alt-A without selection ?
		if (stxt === "" && !t) {
		  JSmodal.prompt(`
		    stag = JS.val('#JSid');
		    zentaga1(stag);
		    JSmodal.close();
		    editor.focus();
		    return;`,
		    "Enter key word to insert code:");
		  JS.doq("#JSid").focus();
		  return;
		}
		// its Alt-W
		if (t) {
			stag = gvar.zenw;
			zentaga2(stag);
			return;
		}
		// its Alt-A with selected text
		JSmodal.prompt(`
	    stag = JS.val('#JSid');
	    zentaga2(stag);
	    JSmodal.close();
	    editor.focus();
	    return;`,
	    `<pre>Enter tag or:<br>
	    $  ==> $\{selection\}<br>
	    *  ==> *selection*<br>
	    _  ==> _selection_<br>
	    ** ==> **selection**<br>
	    __ ==> __selection__<br>
	    /  ==> /* selection */<br>
	    !  ==> &lt;!-- selection --><br>
	    \" ==> \"selection\"<br>
	    \' ==> \'selection\'<br>
	    scase Sentence-Case</pre>
	    `);
	  JS.doq("#JSid").focus();
	  return;
	  //  "Enter tag or $ | * | _ | ** | __ | ! | / | \" | \' | scase");
	}

	function zentaga2(stag) {
		let stxt = "";
		stxt = editor.getSelectedText();
		if (stag === null) return;
		//
		switch (stag) {
			case "scase":
				stxt = JS.titleCase( stxt );
				break;
      case "!":
          stxt = "\x3c!-- " + stxt + " --\x3e";  // html comment (partial line)
          break;
      case "/":
          stxt = "/* " + stxt + " */";  // CSS/PHP comment (partial line)
          break;
      case "$":
          stxt = "${" + stxt + "}";   // template string
          break;
      case "*":
          stxt = "*" + stxt + "*";  // Mup Italic
          break;
      case "**":
          stxt = "**" + stxt + "**";  // Mup Bold
          break;
      case "_":
          stxt = "_" + stxt + "_";  // Mup Italic
          break;
      case "__":
          stxt = "__" + stxt + "__";  // Mup Bold
          break;
      case "'":
          stxt = "'" + stxt + "'";  // quote for MD
          break;
      case "\"":
          stxt = "\"" + stxt + "\"";  // quote for MD
          break;
			default:
				stxt = "<" + stag + ">"+stxt+"</" + stag + ">";
		}
		gvar.zenw = stag;
		editor.insert(stxt);
	}

  function zentaga1(s) {
      if (s === "") return;
      if (s === null) return;
  		if (atags[s] !== undefined) {
  			editor.insert(atags[s]);  // stag is a valid key value
  			return;
  		}  // stag not a valid key value
  		editor.insert("<" + s + "></" + s + ">");
		  return;
  }

    /***
        OPENS AN EXTERAL BROWSER WINDOW FOR CODE CLIPS
        AND USEFUL DEV LINKS
    ***/

	function launchClips() {
		window.open('ieditDevL.html', 'blank',
			'menubar=1,toolbar=0,width=830,height=650,screenX=50,screenY=25,location=0');
	}

    /***
        Navigate directly to mark1/index.php and render
    ***/

  // function goDoc() {
  //   gvar.dname = ".";
  //   listAction('⇓md');
  // }
    /***
        OPENS A NEW TAB WITH THE I-Edit HELP FILE
    ***/

  function launchHelp() {
		window.open('ieditHelp.html', 'blank');
  }

    /***
        OPENS A NEW TAB TO DO A FILE UPLOAD
    ***/

  function upLoadFile() {
    open("ieditUfile.php?cdir=" + gvar.dname);
    getFileList();
  }

  function downloadFile() {
    let fpath = gvar.dname+"/"+gvar.fname;
    let msg = `
      <br>
      <center><big><a href="${fpath}" download>download ${fpath}</a></big></center>
      <br><br>
    `;
    JSmodal.open(0, msg);
  }

    /***
        PRESS CTRL KEY AND DOUBLE CLICK THE HEADER TO CHANGE HEADER BACKGROUND
    ***/
  function changeBg(event) {
      if (event.ctrlKey) {
        gvar.bkinx +=1;
        if (gvar.bkinx > 4) {
            gvar.bkinx = 0;
        }
        JS.css('#HDR').background = 'url(' + bkgs[gvar.bkinx] + ')';
        JS.setCookie("save_ieditbg", bkgs[gvar.bkinx], 300);
      }
  }

  // the following captures a CRLF in the file input field and
  // treats it like hitting the "Save" button or pressing Ctrl-s

document.getElementById("FILN").addEventListener("keydown", function(event) {
  if (event.keyCode === 13) {  // execute "Save" with CRLF in file input field
    event.preventDefault();
    putFile();
    // return;
  }
});

	// the following toggles the 'save' button if the text is "dirty" or "saved"

editor.on("input", function() {
		gvar.saveButton.disabled = editor.session.getUndoManager().isClean();
});

  // Start with Save button disabled
setTimeout(function(){ JS.attr("#SBUT", "disabled", true); }, 1000);

  // Check to save file before closing browser tab

window.addEventListener('beforeunload', function (e) {
  if (gvar.saveButton.disabled)
    e.preventDefault();  // Cancel the event
  else
    e.returnValue = 'prompt';  // fire the confirm prompt
});

const JSmodal = {
  closer : 0,  // modal close style: 0=X only|1=Outside Box Or X
              // the value for close is set in JSmodal.open function
  // call this with text to display in 'msg'
  open : function(mode, msg) {
    if (arguments.length < 2) {
      alert("Missing mode arg in JSmodal.open(mode, msg)");
      return;
    }
    JSmodal.closer = mode;
    document.querySelector(".JSmodal-content p").innerHTML = msg;
    document.getElementById('JSmodal').style.display = "block";
  },

  // When the user clicks on <span> (x), close the modal
  close : function() {
    document.getElementById('JSmodal').style.display = "none";
  },

  // confirm uses open always with a 0 open mode
  confirm : function(routine, msg) {
    msg += `
      <br><br>
      <button onclick="${routine}">&nbsp;&nbsp;&nbsp;Confirm&nbsp;&nbsp;&nbsp;</button>
    `;
    JSmodal.open(0, msg);
  },

  // prompt uses open always with a 0 open mode
  prompt : function(routine, msg) {
    msg += `
      <br><br>
      <input type="text" id="JSid" size="32"><br><br>
      <button onclick="${routine}">&nbsp;&nbsp;&nbsp; OK &nbsp;&nbsp;&nbsp;</button>
    `;
    JSmodal.open(0, msg);
  }

};

window.onclick = function(event) {
  if (event.target == document.getElementById('JSmodal')) {
    if (JSmodal.closer === 1) {
      document.getElementById('JSmodal').style.display = "none";
    }
  }
};

</script>

</body>
</html>
