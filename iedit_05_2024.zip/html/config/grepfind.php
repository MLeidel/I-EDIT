<?php
/****
exec.php
Use 'grep' or 'find' for everything
under ../user/. Home directory is 'config'.
****/
extract($_POST);

if (isset($grep)) {
	exec("grep -rn --include='$gfilemask' '$gtarget' ../$gpath", $arro);
}
else {
	if (isset($find)) {
		exec("find ../$gpath -name '$findfile'", $arro);
	}
}
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Grep & Find</title>
	<style>

  body {
    margin: 0px;
    background: #ddd;
    font-family: sans-serif;
    font-size: 12pt;
    margin-left: 25px;
  }

	code {
		font: normal 10pt/12pt monospace;
		white-space: pre;
	}

	fieldset {
	  display: inline-block;
	}

  /* ----------------------------------------- */

  :root {
    --selected: #000; /* color for checkbox/radio selected */
    --unselected: #999; /* color for checkbox/radio unselected */
    --button-bkg: #999; /* button background color */
    --button-clr: black; /* button text color */
    --button-hov: white; /* button hover text color */
    --button-rad: 2px; /* button corner radius */
    --borders: #333; /*text, textarea, select border color */
  }

  /* ----------------------------------------- */

  input[type=checkbox] {
    zoom: 1.5;
    vertical-align: middle;
  }

  input[type=radio] {
    zoom: 1.2;
   vertical-align: middle;
  }

  input[type=checkbox] + label,
  input[type=radio] + label {
    color: var(--unselected);
    font-style: italic;
  }

  input[type=checkbox]:checked + label,
  input[type=radio]:checked + label {
    color: var(--selected);
    font-style: normal;
  }

  label {
      /* zoom: 1.5; */  /* make all bigger or smaller */
      vertical-align: middle;
  }

  /* ----------------------------------------- */

  input[type=button],
  input[type=submit] {
    background-color: var(--button-bkg);
    border: none;
    color: var(--button-clr);
    padding: 2px 5px;
    text-align: center;
    display: inline-block;
    font-size: inherit;
    margin: 2px 2px;
    cursor: pointer;
    border-radius: var(--button-rad);
  }

  input[type=button]:enabled:hover,
  input[type=submit]:enabled:hover {
    color: var(--button-hov);
  }

  input[type=button]:disabled,
  input[type=submit]:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }

  a:hover {
    text-decoration: none;
    background: var(--button-bkg);
    color: var(--button-hov);
  }

  input[type=text],
  input[type=date],
  input[type=search],
  input[type=email],
  input[type=tel],
  input[type=number],
  input[type=password]
  {
   vertical-align: middle;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  -box-sizing: border-box;
  padding:2px;
  font-size: inherit;
  margin: 4px 2px;
  border: thin solid var(--borders);
  }

  textarea, select, fieldset, table, th, td {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  -box-sizing: border-box;
  padding:2px;
  font-size: inherit;
  margin: 2px 2px;
  border: thin solid var(--borders);
  }

  </style>

</head>
<body>
<h1>I-EDIT File System</h1>
<fieldset>
<legend>
	&nbsp;Grep Request &nbsp;</legend>
<form name="frm1" method="post">
	<label for="IN0">Path</label>
	<input type="text" id="IN0" name="gpath" value="<?php echo $gpath ?>"
		title="path on user/ or leave blank" placeholder="appdir/ | blank">
	<br><br>
	<label for="IN1">Grep Target</label>
	<input type="text" id="IN1" name="gtarget" value="<?php echo $gtarget ?>" title="text to search for">
	<br><br>
	<label for="IN2">Grep File Mask&nbsp;&nbsp;</label>
	<input type="text" id="IN2" name="gfilemask" value="<?php echo $gfilemask ?>" title="file or file type">
	<br><br>
	<input type="submit" name="grep" value=" Run ">
</form>
</fieldset>
<div style="float: left;"><br>&nbsp;&nbsp;&nbsp;<br><br><br><br></div><br><br>
<fieldset>
<legend>
	&nbsp;Find File Request&nbsp;</legend>

<form name="frm2" method="post">
	<label for="IN3">Path</label>
	<input type="text" id="IN3" name="gpath" value="<?php echo $gpath ?>"
		title="path on user/ or leave blank" placeholder="appdir/ | blank">
	<br><br>
	<label for="INF">Find File Mask&nbsp;&nbsp;</label>
	<input type="text" id="INF" name="findfile" value="">
	<br><br>
	<input type="submit" name="find" value=" Run ">
</form>
</fieldset>
<p style="clear: both;">
<code>
<?php

if (isset($arro)) {
  $first = true;
  foreach ($arro as $value)
    if ($value !== "../$gpath") {
  		echo htmlentities($value) . " " . filesize($value) . " " .
  		    date ("F d Y H:i:s.", filemtime($value)) . "\n";
    }
}
?>
</code>
</p>
</body>
</html>
