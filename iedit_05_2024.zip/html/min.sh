./jsmin < $1 > min.js

