var JS = {

	htm : function(qs,val) {
		if (arguments.length === 1) {
			return document.querySelector(qs).innerHTML;
		} else {
			document.querySelector(qs).innerHTML = val;
		}
	},

	doq : function(qs) {
		return document.querySelector(qs);
	},

	css : function(qs) {
		var m = document.querySelector(qs);
		var c = m.style;
		return c;
	},

	val : function(qs,val) {
		if (arguments.length === 1) {
			return document.querySelector(qs).value;
		} else {
			document.querySelector(qs).value = val;
		}
	},

	tog : function(qs, xx) {
		var m = document.querySelector(qs);
		var x = m.style;
		if (arguments.length > 1) {
			if (x.visibility === 'hidden') {
					x.visibility = 'visible';
			} else {
					x.visibility = 'hidden';
			}
		} else {
			if (x.display === 'none') {
					x.display = 'block';
			} else {
					x.display = 'none';
			}
		}
	},

	webget : function(url, n) {
		fetch(url).then(function(response) {
			return response.text().then(function(text) {
				webresponse(n, text);	// user function to handle response
			});
		});
	},

	webgetjson : function(url, n) {
		fetch(url).then(function(response) {
			return response.json().then(function(jobj) {
				webresponse(n, jobj);	// user function to handle response
			});
		});
	},

	webpost : function(url, n, qs) {
		fetch(url, {	
			method: 'post',	
			headers: {	
				"Content-type": "application/x-www-form-urlencoded; charset=UTF-8"	
			},
			body: qs
			})
			.then(function(response) {
				return response.text();
			})
			.then(function (text) {
				webresponse(n, text);	// user function to handle response
			})
			.catch(function (error) {	
				console.log('Request failed', error);	
			});
	},

	websend : function(url, qs) {
		fetch(url, {	
			method: 'post',	
			headers: {	
				"Content-type": "application/x-www-form-urlencoded; charset=UTF-8"	
			},
			body: qs
			})
			.catch(function (error) {	
				console.log('Request failed', error);	
			});
	},

};
