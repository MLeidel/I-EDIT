// gencode( length, Uppercase, Lowercase, Numbers, Puctuation )
// created 5/17

function gencode(clen,bUcase,bLcase,bNum,bSpec) {
	var sDigit = "09876543210987654321098765432109";
	var sUCase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	var sLCase = "abcdefghijklmnopqrstuvwxyz";
	var sPunct = ":'.!-=+_][{}?/*$#@.!-=+_]?[";
	var sGenPW = "";
	var sNewPW = "";
	var slen, rn, x;
	var khar = "";

	if (bLcase === true)
		sGenPW = sGenPW + sLCase;
	if (bUcase === true)
		sGenPW = sGenPW + sUCase;
	if (bNum === true)
		sGenPW = sGenPW + sDigit;
	if (bSpec === true)
		sGenPW = sGenPW + sPunct;

	// Get Then length of the concatenated pick strings
	slen = sGenPW.length;

	// assemble the New Code by randomly picking characters from the pick String
	for (x=0; x < clen; x++) {
		rn = Math.floor((Math.random() * slen) + 0);
		khar = sGenPW.charAt(rn);
		sNewPW += khar;
	}
	return sNewPW;
}

