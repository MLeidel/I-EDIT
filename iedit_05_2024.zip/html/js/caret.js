	var Caret = class {
	constructor(id, p) {
		this.pos = p;
		this.id = id;
	}

	setCurPos() {
		this.setCurrentCursorPosition(this.pos);
	}

 	getCurPos() {
		this.pos = this.getCaretCharOffsetInDiv(document.getElementById(this.id));
	}

	getCaretCharOffsetInDiv(element) {
		var caretOffset = 0;
		if (typeof window.getSelection != "undefined") {
			var range = window.getSelection().getRangeAt(0);
			var preCaretRange = range.cloneRange();
			preCaretRange.selectNodeContents(element);
			preCaretRange.setEnd(range.endContainer, range.endOffset);
			caretOffset = preCaretRange.toString().length;
		} else if (typeof document.selection != "undefined" && document.selection.type != "Control") {
			var textRange = document.selection.createRange();
			var preCaretTextRange = document.body.createTextRange();
			preCaretTextRange.moveToElementText(element);
			preCaretTextRange.setEndPoint("EndToEnd", textRange);
			caretOffset = preCaretTextRange.text.length;
		}
		return caretOffset + 2;
	}

	createRange(node, chars, range) {
		if (!range) {
			range = document.createRange()
			range.selectNode(node);
			range.setStart(node, 0);
		}

		if (chars.count === 0) {
			range.setEnd(node, chars.count);
		} else if (node && chars.count > 0) {
			if (node.nodeType === Node.TEXT_NODE) {
				if (node.textContent.length < chars.count) {
					chars.count -= node.textContent.length;
				} else {
					range.setEnd(node, chars.count);
					chars.count = 0;
				}
			} else {
				for (var lp = 0; lp < node.childNodes.length; lp++) {
					range = this.createRange(node.childNodes[lp], chars, range);

					if (chars.count === 0) {
						break;
					}
				}
			}
		}

		return range;
	}

	setCurrentCursorPosition(chars) {
		if (chars >= 0) {
			var selection = window.getSelection();

			var range = this.createRange(document.getElementById(this.id).parentNode, {
				count: chars
			});
			if (range) {
				range.collapse(false);
				selection.removeAllRanges();
				selection.addRange(range);
			}
		}
	}

	focus() {
		document.getElementById(this.id).focus();
	}

}	// end of class

