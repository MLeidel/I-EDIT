// Crylib Object
// this is an ellaborate Ceasar Cipher
// resembles a Vigenere Cipher
// it shifts the ascii code of each plain text character
// by the first digit of each key character's ascii code
// repeating the key characters over the entire plain text

function Crylib() {

	this.enc = function (ptxt, key) {
		var plen = ptxt.length;
		var klen = key.length;
		var x, z, y=0, $e="";
		for (x=0; x < plen; x++) {
			z = key.charCodeAt(y).toString();
			$e += String.fromCharCode(ptxt.charCodeAt(x) + parseInt(z.charAt(1)));
			if (++y >= klen) y = 0;
		}
		return $e;
	}

	this.dec = function (etxt, key) {
		var elen = etxt.length;
		var klen = key.length;
		var x, z, y=0, $p="";	
		for(x=0; x < elen; x++) {
			z = key.charCodeAt(y).toString();
			$p += String.fromCharCode(etxt.charCodeAt(x) - parseInt(z.charAt(1)));
			if (++y >= klen) y = 0;
		}
		return $p;
	}

}
// END Crylib
