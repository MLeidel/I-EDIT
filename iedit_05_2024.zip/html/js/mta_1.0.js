/*
Mta
mta_1.0.js
Programming Textarea
(C) Michael D Leidel, 2018
All Rights Reserved.
-------------------------------
After the library is loaded..
activate with: 
	Mta.listeners.initialize(textarea id);
last modified: 10/06/2019
-------------------------------
tabs
auto indent
hot keys:
ctrl-Enter <br> **
ctrl-Space &nbsp; **
alt-a Zen wrap-around
alt-w Zen repeat last
alt-c HTML comment brackets **
*/

var Mta = Mta || {};
Mta.listeners = {initialize:function(sid) {
	var Oid = document.getElementById(sid);
	Mta.listeners.setTabs(Oid);
	Oid.style.tabSize = 2;
	Mta.listeners.setIndent(Oid);
	Mta.listeners.setZen(Oid);
	Mta.listeners.setOtherKeys(Oid);
}, setTabs:function(TAo) {
	TAo.addEventListener("keydown", function(event) {
		if (event.keyCode === 9 && !event.shiftKey) {
			event.preventDefault();
			var p1, p2;
			var sels = TAo.selectionStart, sele = TAo.selectionEnd, txt = TAo.value;
			if (sels === sele) {
				TAo.value = txt.slice(0, sels) + "\t" + txt.slice(sele);
				TAo.selectionStart = sels + 1;
				TAo.selectionEnd = sels + 1;
				return;
			}
			var stxt = txt.slice(sels, sele);
			var nl = Mta.countNewLines(stxt);
			if (txt.charCodeAt(sele - 1) !== 10) {
				let i1, i2;
				let len = stxt.length;
				while (1) {
					let si = TAo.selectionEnd;
					i1 = txt.indexOf(stxt, si);
					i2 = i1 + len;
					if (i1 >= 0) {
						TAo.selectionStart = i1;
						TAo.selectionEnd = i2;
					} else {
						if (si > 0) {
							TAo.selectionStart = 0;
							TAo.selectionEnd = 0;
							continue;
						}
					}
					return;
				}
			}
			stxt = stxt.replace(/\s+$/g, "");
			stxt = stxt.replace(new RegExp("\n", "g"), "\n\t");
			p1 = txt.slice(0, sels);
			p2 = txt.slice(sele);
			TAo.value = p1 + "\t" + stxt + "\n" + p2;
			TAo.selectionStart = sels;
			TAo.selectionEnd = sele + nl;
			return;
		}
	});
	TAo.addEventListener("keydown", function(event) {
		if (event.keyCode === 9 && event.shiftKey) {
			event.preventDefault();
			var p1, p2;
			var sels = TAo.selectionStart, sele = TAo.selectionEnd, txt = TAo.value;
			if (sels === sele) {
				p1 = txt.slice(0, sels - 1);
				p2 = txt.slice(sels);
				TAo.value = p1 + p2;
				TAo.selectionStart = sels - 1;
				TAo.selectionEnd = sels - 1;
				return;
			}
			var stxt = txt.slice(sels, sele);
			var nl = Mta.countNewLines(stxt);
			if (stxt.charCodeAt(0) > 32) {
				return;
			}
			stxt = stxt.replace(new RegExp("\n\t", "g"), "\n");
			p1 = txt.slice(0, sels);
			p2 = txt.slice(sele);
			TAo.value = p1 + stxt.slice(1) + p2;
			TAo.selectionStart = sels;
			TAo.selectionEnd = sele - nl;
			return;
		}
	});
}, setIndent:function(TAo) {
	TAo.addEventListener("keydown", function(event) {
		if (event.keyCode === 13 && !event.ctrlKey) {
			event.preventDefault();
			var inx, stx, chx, v = TAo.value, s = TAo.selectionStart, e = TAo.selectionEnd;
			for (inx = s - 1; inx > 0; inx-=1) {
				if (v.charCodeAt(inx) === 10) {
					break;
				}
			}
			stx = String.fromCharCode(10);
			if (inx > 0) {
				inx+=1;
			}
			chx = v.charCodeAt(inx);
			while (chx === 32 || chx === 9) {
				stx += String.fromCharCode(chx);
				inx+=1;
				chx = v.charCodeAt(inx);
			}
			TAo.value = v.slice(0, s) + stx + v.slice(e);
			TAo.selectionStart	= s + stx.length;
			TAo.selectionEnd = s + stx.length;
			return;
		}
	});
}, setZen:function(TAo) {
	var lastWrap = "";
	TAo.addEventListener("keydown", function(event) {
		if (String.fromCharCode(event.which).toLowerCase() === "a" && event.altKey) {
			zentage(0);
			event.preventDefault();
			return;
		}
	});
	TAo.addEventListener("keydown", function(event) {
		if (String.fromCharCode(event.which).toLowerCase() === "w" && event.altKey) {
			zentage(1);
			event.preventDefault();
			return;
		}
	});
	
  function zentage(m) {
  	var p1, p2, stag, t1, t2, stxt;
  	var sels = TAo.selectionStart, sele = TAo.selectionEnd, txt = TAo.value;
  	stxt = txt.slice(sels, sele);
  	p1 = txt.slice(0, sels);
  	p2 = txt.slice(sele);
  	if (m === 0) {
  		stag = prompt("Enter tag abbreviation\n or command");
  		if (stag === null) return;
  		lastWrap = stag;
  	} else {
  		stag = lastWrap;
  	}
  	if (stag === "ucase") {
  		t1 = "";
  		t2 = "";
  		stxt = stxt.toUpperCase();
  	} else {
  		if (stag === "lcase") {
  			t1 = "";
  			t2 = "";
  			stxt = stxt.toLowerCase();
  		} else {
  			if (stag === "\"") {
  				t1 = "\"";
  				t2 = "\"";
  			} else {
  				if (stag === "'") {
  					t1 = "'";
  					t2 = "'";
  				} else {
        		if (stag === "") {
        			stag = "--";
        		}
  					t1 = "";
  					t2 = "";
  					stxt = stag.repeat(10);
  				} 
  			}
  		}
  	}
  	txt = p1 + t1 + stxt + t2 + p2;
  	TAo.value = txt;
  	TAo.selectionEnd = txt.length - p2.length;
  	TAo.selectionStart = txt.length - p2.length;
  	return;
  }
}, setOtherKeys:function(TAo) {
		/*
			ctrl-Enter <br>
			ctrl-Space &nbsp;
			ctrl-c
		*/
		TAo.addEventListener("keydown", function(event) {
			if (event.keyCode === 13 && event.ctrlKey) {
				event.preventDefault();
				Mta.insClip(TAo, "<br>");
				return;
			}
			if (event.keyCode === 32 && event.ctrlKey) {
				event.preventDefault();
				Mta.insClip(TAo, "&nbsp;");
				return;
			}
			if (String.fromCharCode(event.which).toLowerCase() === "c" && event.altKey) {
				event.preventDefault();
				Mta.insClip(TAo, "\x3c!--\t--\x3e");
				return;
			}
		});
	}
};	// END Mta.listeners

Mta.countNewLines = function (txt) {
	var inx, c = 0;
	for (inx = 0;inx < txt.length; inx+=1) {
		if (txt.charAt(inx) === "\n") {
			c+=1;
		}
	}
	return c;
};

Mta.insClip =	function (TAo, itext) {
	var tav = TAo.value;
	var strPos = TAo.selectionStart;
	var front = tav.slice(0, strPos);
	var back = tav.slice(strPos);
	TAo.value = front + itext + back;
	TAo.selectionEnd = strPos + itext.length;
	TAo.focus();
};

//// end of Mta
