<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset='UTF-8' />
	<meta name='viewport' content='width=device-width, initial-scale=1' />
	<title>MichaelLeidel.NET</title>
  <link rel="preconnect" href="https://fonts.gstatic.com" />
  <link href="https://fonts.googleapis.com/css2?family=Montserrat&family=Permanent+Marker&family=Playfair+Display&display=swap"
          rel="stylesheet" />
	<link rel="stylesheet" href="home.css" />
</head>
<body>
  <h3 class="head">MichaelLeidel.NET</h3>
<br><br>
<a scan class="linkstyle" href="https://michaelleidel.net/wordle"
    target="_blank" class="link4">Wordle Dictionary Assistant </a> &nbsp;*
<br><br>
<a scan class="linkstyle" href="https://michaelleidel.net/farkle"
    target="_blank" class="link4">2 player Farkle Scorer </a> &nbsp;*
<br><br>
<a scan class="linkstyle" href="https://taozen.info"
    target="_blank" class="link4">taozen Info</a> &nbsp;*
<br><br>
<a scan class="linkstyle" href="https://tekvow.net"
    target="_blank" class="link4">Tekvow</a> &nbsp;*
<br><br>
<a scan class="linkstyle" href="https://michaelleidel.net/air"
    target="_blank" class="link4">Airnow</a> &nbsp;*
<br><br>
<a scan class="linkstyle" href="https://michaelleidel.net/CKDfoods"
    target="_blank" class="link4">Na-Pr-P-k food lookup</a> &nbsp;*
<br><br>
<a scan class="linkstyle" href="https://github.com/MLeidel" title="my github repos"
    target="_blank" class="link4" title="my Github repositories">Coding</a>
<br><br>
<a scan class="linkstyle" href="https://michaelleidel.net/speedtest"
    target="_blank" class="link4" title="rough estimate of language performances">Language Comparisons</a>
<br><br>
<a scan class="linkstyle" href="https://michaelleidel.net/sqlcel"
    target="_blank" class="link4" title="Datascience tool">SequelCell</a>
<br><br>
<a scan class="linkstyle" href="hate.html" title="PG-13"
    target="_blank" class="link4">Hate in the USA <small style="font-family:helvetica">(PG-13)</small></a>
<br><br>
<a scan class="linkstyle" href="https://michaelleidel.net/Tubingen"
    target="_blank" class="link4">Historical Jesus <small style="font-family:helvetica">(PG-13)</small></a>
<br><br>
<a scan class="linkstyle" href="https://sites.google.com/view/gunsgunsguns/home"
    target="_blank" class="link4">Guns Guns Guns <small style="font-family:helvetica">(PG-13)</small></a>

<!--<br><br>-->
<!--<a scan class="linkstyle" href="system.html"-->
<!--    target="_blank" class="link4">Workstation</a>-->

<br><br><br>* <small>works on phone</small><br><br>
<a scan href="visitors.html" target="_blank"><i>locate visitors to this site</i></a> <br><br><br><br>
The mind is everything. What you think you become. -Buddha
</body>
</html>









