<?Php /* webdevL.php
returns webdev.dat in
select..options for
TArea editor.html
*/
// security
if ($_COOKIE["valid"] !== "iedit")
  header("location: index.php");

extract($_POST);

if ($key == "list") {
	$wd = file_get_contents ( "config/webdev.dat" );
	$wd = htmlentities ($wd);
	$wd = str_replace( "\n", "<br>\n", $wd );
	$inx	= 0;
	$pos1 = 0;
	$pos2 = 0;
	$len	= 0;

	// get the clip titles for a list box
	$pos1 = strpos ( $wd, "CP=", $pos2 );
	do {
		$pos1 += 3;
		$pos2 =	strpos($wd, "<br>", $pos1);
		$len = $pos2 - $pos1;
		$aTitle[$inx] = substr( $wd, $pos1, $len );
		$pos1 = strpos ( $wd, "CP=", $pos1 );
		$inx++;
	} while ($pos1 !== false);

	$sOut = "<select id='CLIP' size='12' onchange='dispCode();'>\n";
	for ($pos1=0; $pos1 < $inx; $pos1++)
	{
		$sOut .= "<option>$aTitle[$pos1]</option>\n";
	}
	$sOut .= "</select>\n";

	$sOut .= "<br><br>
		<input type=\"search\" id=\"ENT\" size=\"18\">
		<input type=\"button\" onclick=\"listLookUp('ENT','CLIP')\" value=\"Look\">&nbsp;&nbsp;&nbsp;&nbsp;";

	echo $sOut;
}

else

{
	$wd = file_get_contents ( "config/webdev.dat" );
// 	$wd = htmlentities ($wd);
// 	$wd = str_replace( "\n", "<br>\n", $wd );
	$inx	= 0;
	$pos1 = 0;
	$pos2 = 0;
	$len	= 0;

	$pos1 = strpos ( $wd, "CP=", $pos2 );
	do {
		$pos1 += 3;
		// first the title
		$pos2 =	strpos($wd, "\n", $pos1);
		$len = $pos2 - $pos1;
		$pos1 = $pos2+1;
		$pos2 = strpos ( $wd, "CP=", $pos1 );
		if ($pos2 === false)
			$len = strlen($wd) - $pos1;
		else
			$len = $pos2 - $pos1;
		$aCode = substr( $wd, $pos1, $len );

		if ($inx == $pinx) {
			echo $aCode;
			exit;
		}

		$pos1 = $pos2;
		$inx++;
	} while ($pos2 !== false);

}