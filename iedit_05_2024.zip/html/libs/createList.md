
#createList

include "libs/createList.php";

Used to build a formatted HTML select list.

---

###function: createList(
1.  array or csv string
1.  the SELECT id (string)
1.  [onchange code] or FALSE
1.  [first option text] or FALSE
1.  [size value] or FALSE

Examples:
```php
echo createList(
      $array,
      "ID",
      false,
      "select one",
      false);

echo createList(
      $myArr,
      "SEL",
      "alert(this.options[this.selectedIndex].text)",
      false,
      5);
```
---

<small>end of document</small>
