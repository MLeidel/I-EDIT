<?php 
/*  Use: include "../libs/tblrows.php"
Helps format data into an HTML a table.
Formats HTML table one row at a time.
The row can be in the form of: a string
with comma delimited values; an
array; or a row returned from
a database resultset. These
functions will not create the HTML
<table> and </table> tags. That and
any styling is left to the coder.

  [Optionally, the 1st column of the
  constructed HTML table may contain
  a link to a Javascript function
  whose single parameter value is determined
  by the last column value of the input
  array or resultset row. When this
  option is used do not include the 
  column NAME for this last column in 
  the table heading. You will have to
  provide the actual Javascript 
  function in your rendered page.]
--------
CONSTRUCTOR SETS THE COLUMN FORMATS
AND AN OPTIONAL FUNCTION NAME
Tblrow( String, [function_name] )
<   left justify column data
d   format to *.99 and right justify
>   right justify column data
-   center column data
--------
examples:
$Trow = new Tblrow("<,d,d,>,-", "alert");  // using optional function name
$Trow->tblhead("Name,Amount,Age,Account,Type");  // array or csv string
$Trow->tblrow( $array ); // array or csv string
--------
*/

class Tblrow {
  private $afmt;  // format codes
  private $tgt;   // optional URL for links
  
	function __construct($cols, $url = "") {
	  // sets the column formats
		$this->afmt = explode( "," , $cols );
		if ($url !== "") {
		  $this->tgt = $url;
		} else {
		  $this->tgt = "";
		}
	}

  function tblrow($items) {
    
    if (is_array($items)) {
      $ar = $items;
    } else {
      $ar = explode( ",", $items );  // items was a CSV string
    }
    
    if ($this->tgt !== "") {
      $cc = count($ar) - 1;
      $tbl_row = "<tr><td><a onclick=\"$this->tgt($ar[$cc]);\">&nbsp;&nbsp;&raquo;&nbsp;&nbsp;</a></td>";
      
      $tbl_row .= "<td";
    } else {
      $cc = count($ar);
      $tbl_row = "<tr><td";
    }

    for( $x=0; $x < $cc; $x++) {
      switch ( trim($this->afmt[$x]) ) {
        case "<":     // left align
          $tbl_row .= ">" . $ar[$x] . "</td>";
          break;
        case ">":     // right align
          $tbl_row .= " align='right'>" . $ar[$x] . "</td>";
          break;
        case "d":     // decimal right align
          if ( is_numeric($ar[$x]) ) {
            $num = number_format($ar[$x], 2);
          } else {
            $num = $ar[$x];
          }
          $tbl_row .= " align='right'>" . $num . "</td>";
          break;
        case "-":     // center in cell
          $tbl_row .= " align='center'>" . $ar[$x] . "</td>";
          break;
      } // end switch
      if ($x === $cc - 1) {
        $tbl_row .= "</tr>\n";
      } else {
        $tbl_row .= "<td";
      }
    } // end for
    return $tbl_row;
  } // end function
  
  function tblhead($head) {
    if (is_array($head)) {
      $ath = $head;
    } else {
      $ath = explode( ",", $head );  // CONVERT STRING TO ARRAY
    }
    if ($this->tgt !== "") {        // INSERT 'CLICK' COLUMN HEADER
      array_splice($ath, 0, 0, '^');
    }
    $tbl_row = "<tr><th>";
    for( $x=0; $x < count($ath); $x++) {
      $tbl_row .= trim($ath[$x]) . "</th>";
      if ($x === count($ath) - 1) {
        $tbl_row .= "</tr>\n";
      } else {
        $tbl_row .= "<th>";
      }
    } // end for
    return $tbl_row;
  } // end function

} // end class
?>