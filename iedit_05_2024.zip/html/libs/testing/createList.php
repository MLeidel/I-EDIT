<?php // createList.php
/* HTML <select> functions
createList(
  array of items or csv string,
  ID (string),
  onchange command or FALSE,
  first option ITEM (string) or FALSE,
  size attribute or FALSE
);
Returns the HTML select/option code
EXAMPLES:
  see createList.html
*/

function createList($items, $id, $onchg=FALSE, $firstopt=FALSE, $size=FALSE) {
  if (is_array($items)) {
    $ar = $items;
  } else {
    $ar = explode( ",", $items );  // items was a CSV string
  }
  $sz = "";
  if ($size !== FALSE) $sz = "size='$size'";
  $oc = "";
  if ($onchg !== FALSE) $oc = "onchange='$onchg'";
  
  $html = "<select id=\"$id\" $sz $oc>\n";
 
  if ($firstopt !== FALSE) {
    $html .= "<option>$firstopt</option>\n";
  }
	for ($x = 0; $x < count($ar); $x++) {
		$html .= "<option>$ar[$x]</option>\n";
	}
	$html .= "</select>\n";
	return $html;
} // end function


// build list using an array of items
$myArr = array("item one of array","item TWO of arr","item Three in array","item four in array","item five in array");

echo createList($myArr,"SEL","alert(this.options[this.selectedIndex].text)","click to select",false);
echo "<br><br>";
echo createList($myArr,"LST","alert(\"changed\")",false,3);
echo "<br><br>";

// build list using a CSV string
$myArr = "adsfsa,sdfsd,rwerwer,56456,fghfd,dfghdfgh,ertert,tyutyu,fgjhghj";
echo createList($myArr,"LID","console.log(this.selectedIndex)",false,5);

?>


