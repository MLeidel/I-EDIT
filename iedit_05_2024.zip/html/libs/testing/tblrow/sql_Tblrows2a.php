<?php 
/*
NOTE: in this example we inserted a javascript function call
when ever the heading is clicked.
*/
include "Tblrows.php";
// include "../libs/Tblrows.php";

$db = new SQLite3('savetest.db');

$sql = "SELECT in_mem_honor, amount_paid, remarks, attended, member_rowid
from tbldonation
where in_mem_honor <> ''";

$results = $db->query($sql);  // query database
$ar = $results->fetchArray(SQLITE3_NUM); // get the 1st row (array)
if (!$ar) {
	die("No rows returned");
}

//  create new Tblrow object
//  see sql_Tblrow2b.php for actual function call example
$Trow = new Tblrow("<,d,<,-", "alert");

echo "<table cellspacing=0 cellpadding=4 border=1>\n";  // print the open table tag



// EXAMPLE TO RETURN THE HEADING WITH onclick ACTION:
// NOTE: NO COMMAS INSIDE THE "STRING" HEADERS
// $ahead = "
// <a onclick='alert(0);'>Memory of</a>,
// <a onclick='alert(1);'>Amount</a>,
// <a onclick='alert(2);'>Remarks</a>,
// <a onclick='alert(\"Three | 3\");'>Attended</a>
// ";
//// $ahead is an array instead of a string
// NOTE: NOW YOU CAN PUT COMMAS INSIDE THE HEADERS
$ahead = array(
  "<a onclick='alert(0);'>Memory, of</a>",
  "<a onclick='alert(1);'>Amount</a>",
  "<a onclick='alert(2);'>Remarks</a>",
  "<a onclick='alert(\"Three\", 3);'>Attended</a>"
  );
echo $Trow->tblhead($ahead);    // 1 string arg



// loop through rest of result set outputting each formatted row of data
do {
  
	// process rows in $ar
  echo $Trow->tblrow($ar); // 1 array arg
  // print_r($ar);
  // echo("<br><br>");
  
} while ( $ar = $results->fetchArray(SQLITE3_NUM) );

echo "</table>\n";  // print the close table tag
