<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset='UTF-8'>
	<meta name='viewport' content='width=device-width, initial-scale=1'>
	<title></title>
	<script type="text/javascript">
	
	  function rowfunc(key) {
	    alert("process lookup using: " + key);
	  }
	  
	</script>
</head>
<body>
<h3>Row Click Function with KEY passed from row</h3>
<?php
/*
NOTE: Tblrows will process the result set BY INDEX
NOT BY ASSOCIATIVE column name.
In this test case using SQLite the method
to use would be: fetchArray(SQLITE3_NUM)
*/
include "Tblrows.php";
// include "../libs/Tblrows.php";

$db = new SQLite3('savetest.db');

$sql = "SELECT in_mem_honor, amount_paid, remarks, attended, member_rowid
from tbldonation
where in_mem_honor <> ''";

$results = $db->query($sql);  // query database
$ar = $results->fetchArray(SQLITE3_NUM); // get the 1st row (array)
if (!$ar) {
	die("No rows returned");
}


// CREATE NEW TBLROW OBJECT WITH OPTIONAL CLICK ROW FUNCTION
$Trow = new Tblrow("<,d,<,-", "rowfunc");


echo "<table cellspacing=0 cellpadding=4 border=1>\n";  // print the open table tag

// method to return the heading
echo $Trow->tblhead("Memory of,Amount,Remarks,Attended");    // 1 string arg

// loop through rest of result set outputting each formatted row of data
do {
  
	// process rows in $ar
  echo $Trow->tblrow($ar); // 1 array arg
  // print_r($ar);
  // echo("<br><br>");
  
} while ( $ar = $results->fetchArray(SQLITE3_NUM) );

echo "</table>\n";  // print the close table tag
?>
</body>
</html>
