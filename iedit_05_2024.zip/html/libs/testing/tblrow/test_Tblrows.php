<?php 
include "Tblrows.php";

// create new Tblrow object
$Trow = new Tblrow("<,d,d,>,<");  // left, decimal, decimal, right, left

echo "<table cellspacing=0 cellpadding=4 border=1>\n";  // print the open table tag

// method to return the heading
echo $Trow->tblhead("Name,Amount,Age,Account,Type");    // 1 string arg

// method to return a row of data
echo $Trow->tblrow(array("Mike Leidel",123.50,"17","100002","elephant")); // 1 array arg
echo $Trow->tblrow("Mike Speidel,1.25,18,10033,male"); // 1 CSV arg

echo "</table>\n";  // print the close table tag
