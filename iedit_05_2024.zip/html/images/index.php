<?php
/* mldev.io/TArea/user/bkm
index.php
For personal use only.

bkmarx.sqlite TABLE:
bm_url		varchar(255)	YES
bm_name		varchar(32)		YES
bm_label	varchar(32)		YES
bm_user		varchar(20)		NO

*/
error_reporting(E_ALL);
ini_set('display_errors', 1);

$db = new SQLite3('bkmarx.sqlite');

// Build array for TAB names
$x = 0;
$sql = "SELECT distinct bm_label from bkmarks where bm_user = 'michaell' order by bm_label";
$results = $db->query($sql);
while ($row = $results->fetchArray()) {
	$aLabels[$x++] = $row[0];
}

// 	while ( list($inx, $url, $name, $lbl, $u) = $results->fetchArray() )
// 	{
// 		if ($lname != $lbl)
// 		{
// 			echo "</p></div>\n";
// 			$lname = $lbl;
// 			echo "<div id='$lname'><p>\n";
// 		}
// 		echo "<a href='$url' class='bmarkline' target='_b' title='$url'>$name</a>&nbsp;&nbsp;&nbsp;
// 		<button class='edit' onclick='doEdit($inx)'></button><br />\n";
// 	}
?>
<!doctype html>
<html lang="en">
 <head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="cache-control" content="no-cache">
	<meta http-equiv="pragma" content="no-cache">
	<title>Template</title>

	<link rel="stylesheet" href="style1.css" type="text/css" />
	<script type="text/javascript" src="script1.js"></script>
	<script type="text/javascript" src="../js/myJS-1.2.min.js"></script>
 </head>

 <body id="BOD">
	<div class="container">

	<div id="pgheader"> <!-- REGULAR HEADING -->
	<center>
		<br>
		<h1>Mobile Ready Template</h1>
	</center>
	</div>

	<div id="pgsmheader"> <!-- SMALL HEADING	-->
	<h2>Mobile Ready Template</h2>
	</div>

<!-- ############## MAIN COLUMNS IN FLEX CONTAINER ################ -->
<br>

	<div class="flex-container">

		<div id="pgcolm1" class="flex-item">

		Lorem ipsum dolor sit amet, consectetur adipiscing elit.
		Phasellus scelerisque sodales condimentum. Quisque facilisis,
		ipsum vel pretium pretium, nisi turpis suscipit odio,
		eu vulputate nulla diam a nunc. Quisque aliquet metus in
		quam consectetur in congue enim sollicitudin.
		Curabitur vehicula erat nec elit ultrices ac auctor risus cursus.
		Fusce aliquet sagittis lacinia. Pellentesque habitant morbi tristique
		senectus et netus et malesuada fames ac turpis egestas.
		<br><br>
		Pellentesque in turpis id nulla molestie ornare eu ut elit.
		Maecenas posuere lacinia vehicula. Nunc scelerisque blandit nibh,
		sed pretium magna tempor sed. In fermentum, ipsum eu dapibus dignissim,
		nulla lorem lobortis velit, nec pharetra tortor leo ut mauris.
		Donec lacus augue, congue blandit faucibus ut, convallis in massa.
		Donec feugiat aliquet venenatis. Curabitur erat ante, iaculis vel
		varius sit amet, venenatis at turpis. Aliquam ornare ullamcorper nunc,
		eget tincidunt quam congue sed. Suspendisse in lacus velit,
		viverra porta metus.

		</div>

		<div id="pgcolm2" class="flex-item">

		Lorem ipsum dolor sit amet, consectetur adipiscing elit.
		Phasellus scelerisque sodales condimentum. Quisque facilisis,
		ipsum vel pretium pretium, nisi turpis suscipit odio,
		eu vulputate nulla diam a nunc. Quisque aliquet metus in
		quam consectetur in congue enim sollicitudin.
		Curabitur vehicula erat nec elit ultrices ac auctor risus cursus.
		Fusce aliquet sagittis lacinia. Pellentesque habitant morbi tristique
		senectus et netus et malesuada fames ac turpis egestas.
		<br><br>
		Pellentesque in turpis id nulla molestie ornare eu ut elit.
		Maecenas posuere lacinia vehicula. Nunc scelerisque blandit nibh,
		sed pretium magna tempor sed. In fermentum, ipsum eu dapibus dignissim,
		nulla lorem lobortis velit, nec pharetra tortor leo ut mauris.
		Donec lacus augue, congue blandit faucibus ut, convallis in massa.
		Donec feugiat aliquet venenatis. Curabitur erat ante, iaculis vel
		varius sit amet, venenatis at turpis. Aliquam ornare ullamcorper nunc,
		eget tincidunt quam congue sed. Suspendisse in lacus velit,
		viverra porta metus.

		</div>

	</div> <!--	end flex-container -->

	</div> <!-- end container -->

	<hr>

	<div id="pgfooter">	<!-- FOOTERS	-->
	<center>
		Flexbox Mobile Web Template
		<input type="button" onclick="changeBkgd();" value="Change Background">
	</center>
	</div>
	<div id="pgsmfooter">
		Flexbox Mobile Web Template
		<!-- <input type="button" onclick="changeBkgd();" value="Change Background"> -->
	</div>

</body>
</html>

