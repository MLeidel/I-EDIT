<?php
/****
exec.php
Use 'grep' or 'find' for everything
under ../user/. Home directory is 'config'.
****/
extract($_POST);

if (isset($grep)) {
	exec("grep -rn --include='$gfilemask' '$gtarget' $gpath", $arro);
}
else {
	if (isset($find)) {
	  if ($olds === "") { // was a find and replace requested?
		  exec("find $fpath -name '$findfile'", $arro);
	  } else {
	    exec("find $fpath -type f -exec sed -i '' -e 's/$olds/$news/g' {} \\;", $arro);
	  }
	}
}
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Grep & Find</title>
	<style>

  body {
    margin: 0px;
    background: #ddd;
    font-family: sans-serif;
    font-size: 12pt;
    margin-left: 25px;
  }

	code {
		font: normal 10pt/12pt monospace;
		white-space: pre;
	}

	fieldset {
	  display: inline-block;
	  float: left;
	}

  /* ----------------------------------------- */

  :root {
    --selected: #000; /* color for checkbox/radio selected */
    --unselected: #999; /* color for checkbox/radio unselected */
    --button-bkg: #999; /* button background color */
    --button-clr: black; /* button text color */
    --button-hov: white; /* button hover text color */
    --button-rad: 2px; /* button corner radius */
    --borders: #333; /*text, textarea, select border color */
  }
  label {
      /* zoom: 1.5; */  /* make all bigger or smaller */
      vertical-align: middle;
  }

  /* ----------------------------------------- */

  input[type=button],
  input[type=submit] {
    background-color: var(--button-bkg);
    border: none;
    color: var(--button-clr);
    padding: 2px 5px;
    text-align: center;
    display: inline-block;
    font-size: inherit;
    margin: 2px 2px;
    cursor: pointer;
    border-radius: var(--button-rad);
  }

  input[type=button]:enabled:hover,
  input[type=submit]:enabled:hover {
    color: var(--button-hov);
  }

  input[type=button]:disabled,
  input[type=submit]:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }

  a:hover {
    text-decoration: none;
    background: var(--button-bkg);
    color: var(--button-hov);
  }

  input[type=text],
  input[type=search],
  {
   vertical-align: middle;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  -box-sizing: border-box;
  padding:2px;
  font-size: inherit;
  margin: 4px 2px;
  border: thin solid var(--borders);
  }

  textarea, select, fieldset, table, th, td {
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  -box-sizing: border-box;
  padding:4px;
  font-size: inherit;
  margin: 2px 2px;
  border: thin solid var(--borders);
  }
  fieldset {
    margin-left: 10px;
  }
  </style>

</head>
<body>
<h1>I-Edit File System</h1>
<small>Everything is case sensitive and recursive</small><br><br>
<fieldset>
<legend>
	&nbsp;Grep Request &nbsp;</legend>
<form name="frm1" method="post">
	<label for="IN0">Path</label>
	<input type="search" id="IN0" name="gpath" value="<?php echo $gpath ?>"
		title="directory or leave blank" placeholder="path | blank">
	<br><br>
	<label for="IN1">Grep Target</label>
	<input type="search" id="IN1" name="gtarget" value="<?php echo $gtarget ?>" title="text to search for">
	<br><br>
	<label for="IN2">File Mask&nbsp;&nbsp;</label>
	<input type="search" id="IN2" name="gfilemask" value="<?php echo $gfilemask ?>">
	<br><br>
	<input type="submit" name="grep" value=" Run ">
</form>
</fieldset>
<div style="float: left;"></div>
<fieldset>
<legend>
	&nbsp;Find File Request&nbsp;</legend>

<form name="frm2" method="post">
	<label for="IN3">Path</label>
	<input type="search" id="IN3" name="fpath" value="<?php echo $fpath ?>"
		title="directory, fullpath, or leave blank" placeholder="path | blank | fullpath">
	<br><br>
	<label for="INF">File Mask&nbsp;&nbsp;</label>
	<input type="search" id="INF" name="findfile" value="">&nbsp;**
	<br><br>
	<i>Replace text IN files (<abbr title="use with caution!">optional</abbr>):</i>
	<input type="search" id="SEA" name="olds" size="12" placeholder="old text" value="<?php echo $olds ?>">&nbsp;
	<input type="search" id="REP" name="news" size="12" placeholder="new text" value="<?php echo $news ?>">
	<br>
	<input type="submit" name="find" value=" Run "><br>
<center><small><i>
  &nbsp;&nbsp;&nbsp;** When using <b>"Replace text IN files"</b> do not use the<br>"Find File Mask" field --
  type the fullpath for the file(s)<br>in the <b>"Path"</b> field. (e.g. <code>test/*.html</code>)
</form>
</fieldset>
<p style="clear: both;">
<code>
<?php

if (isset($arro)) {
  $first = true;
  foreach ($arro as $value)
    if ($value !== "../$gpath") {
  		echo htmlentities($value) . " " . filesize($value) . " " .
  		    date ("F d Y H:i:s.", filemtime($value)) . "\n";
    }
}
?>
</code>
</p>
</body>
</html>
