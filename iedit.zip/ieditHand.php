<?Php // ieditHand.php
// POST vars:
// $key = "";       // action
// $cpath = "";     // current path
// $fna = "";       // file or dir name
// $txt = "";       // file content
/*
This source mentions the "highlight.js" library
Copyright (c) 2006, Ivan Sagalaev
All rights reserved.
*/
// security
if ($_COOKIE["valid"] !== "iedit")
  header("location: index.php");

error_reporting(E_ALL);
ini_set('display_errors', '1');

extract($_POST);

if (isset($fna)) {
    if (strpos($fna, ".md") !== false) {
        include "libs/Parsedown.php";
        include "libs/ParsedownExtra.php";
    }
}

// plogf("%s %s | %s | %s", array("POST vars: ", $key, $cpath, $fna));

// MD2Html components

function createHTML($mdfile, $mdtext) {
  $parsedown = new ParsedownExtra();
  $content = $parsedown->text($mdtext);       // convert md to html
  $head = "
  <!DOCTYPE HTML>
  <html lang='en-US'>
  <head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <title>$mdfile</title>
<!--
This source uses the 'highlight.js' library
Copyright (c) 2006, Ivan Sagalaev
All rights reserved.
-->
  <link rel='stylesheet'
        href='//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.15.10/styles/default.min.css'>
  <script src='//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.15.10/highlight.min.js'></script>

  </head>
  <body>\n";
  $inithighlight = "
  <script>hljs.initHighlightingOnLoad();</script>
  </body>
  </html>";
  $htmlpath = str_ireplace(".md", ".html", $mdfile);  // change the extension
  $htmlcontent = $head . $content . $inithighlight;  // build the html file
  file_put_contents( $htmlpath, $htmlcontent, false );
}

function plogf($fmt, $arr) {
  // Use plogf like printf to write a log entry
  // LIKE: plogf("%s %s | %s", array(xx,xx,xx));
  if (!($fp = fopen('plogger.txt', 'a')))
      return;
  vfprintf($fp, $fmt . "\n", $arr);
  fclose($fp);
}

  ///////////////////////////////////////////////
 // build a select list from directory's files//
///////////////////////////////////////////////
function getFiles()
{
	$inx = 0;
	if ($handle = opendir(".")) {
		while (false !== ($file = readdir($handle))) {
			if ($file != "." && $file != "..") {
				if (is_dir($file)) {
				  $aFiles[$inx] = "⇓" . $file;
				} else {
					$aFiles[$inx] = $file;
				}
				$inx += 1;
			}
		}
		closedir($handle);
	}
    if (isset($aFiles)) sort($aFiles);
	$code = "<select id=\"SEL\" onchange=\"listAction(this.options[this.selectedIndex].text);\">\n";
	$code .= "<option>File &rarr;</option>\n";
    if (isset($aFiles)) {
    	for ($x = 0; $x < count($aFiles); $x++)
    		$code .= "<option>$aFiles[$x]</option>\n";
    }
	$code .= "</select>\n";
	return $code;
}

function getFileName($path) {
	$path_parts = pathinfo($path);
	return $path_parts['basename'];
}

             /////////////////////////
            // M A I N   L O G I C //
           /////////////////////////

switch ($key) {

   //////////////////////////////////////////
  // change directory & get list of files //
 //////////////////////////////////////////
  case "CD":
    $rc = @chdir($cpath);
    if ($rc === true) {
      echo getFiles();
    } else {
      @plogf("change directory failed dir = %s", array($cpath));
      $cpath = ".";
      echo getFiles();
    }
    break;

   ///////////////////////
  // get list of files //
 ///////////////////////
  case "F":
    echo getFiles();
    break;

   //////////////////////////////////
  // WRITE FILE CONTENTS TO SERVER//
 //////////////////////////////////
	case "W":
	  if ($cpath == ".") {
	    $fpath = $fna;
	  } else {
	    $fpath = $cpath . "/" . $fna;
	  }
		if ( file_put_contents( $fpath, $txt, false ) === false ) {
		  echo "Fail";
		} else {
          if (pathinfo($fpath, PATHINFO_EXTENSION) == "md") {
            createHTML($fpath, $txt);
          }
		  echo "Success";
		}
		break;

   ////////////////////////////
  // SEND BACK FILE CONTENTS//
 ////////////////////////////
	case "R":
	  $rctxt = @file_get_contents( $cpath . "/" . $fna );
		if ($rctxt !== false) {
		  echo $rctxt;
		} else {
      @plogf("%s - cpath/fna = %s/%s", array('open file failed', $cpath, $fna));
		  echo "open file failed - see plogger.txt";
		}
		break;


   ////////////////////////////
  // DELETE FILE or DIRECTORY/
 ////////////////////////////
	case "X":
		if ($fna === "") {	## dir & files
			$mask = $cpath."/*";
			$bc = array_map( "unlink", glob( $mask ) );
			$bc = @rmdir($cpath);
			if (!$bc)
				echo "Failed";
			else
				echo "Success";
			break;
		}
		if (strpos($fna, "*") !== false) {	## multiple files
			$mask = $cpath."/".$fna;
			$bc = @array_map( "unlink", glob( $mask ) );
			if (!$bc)
				echo "Failed";
			else
				echo "Success";
			break;
		}
		$bc = @unlink($cpath."/".$fna);	## one file
		if (!$bc)
			echo "Failed";
		else
			echo "Success";
		break;

   //////////////////
  // NEW DIRECTORY//
 //////////////////
	case "N":
		$bc = @mkdir($cpath."/".$fna);
		if (!$bc)
			echo "Failed";
		else
			echo "Success";
		break;

   ////////////////////
  // CLONE DIRECTORY//
 ////////////////////
 // $fna is the new directory name
	case "K":
		$bc = @mkdir($fna);
		if (!$bc)
			echo "Failed: Dir Clone";
		else {
			sleep(1);
			$aFile = glob($cpath."/*.*");
			$bc = "";
			foreach($aFile as $f) {
				copy( $cpath."/".getFileName($f), $fna."/".getFileName($f) );
				$bc .= "copied " . $cpath."/".getFileName($f) . " to " . $fna."/". getFileName($f) . "\n";
			}
			echo $bc;
		}
		break;

   ///////////////
  // COPY FILE //
 ///////////////
 // $fna is the file with relative path
    case "CP":
        $r = FALSE;
        $r = @copy( $fna, $cpath."/".getFileName($fna) );
        if ($r === TRUE) {
            @plogf("%s", array("TRUE"));
            echo "Success";
        } else {
            @plogf("%s", array("FALSE"));
            echo "Failed";
        }
        break;

   //////////////////
  // MINIFICATION //
 //////////////////
 // $fna is the file with relative path
    case "MN":
        if ($cpath == ".") {
            $fpath = $fna;
        } else {
            $fpath = $cpath . "/" . $fna;
        }
        // so $fpath is the fullpath
        system("./min.sh " . $fpath);
        sleep(2);
        $minpath = str_ireplace(".js", ".min.js", $fpath);
        copy( "min.js", $minpath );
        echo $minpath;  // send back the minified file name
        break;
        
   //////////////////
  // SAVE SCRATCH //
 //////////////////
 // $txt contains scratch text
    case "SS":
        file_put_contents( "scratch.txt", $txt );
        break;

} // end switch

// end of script