<?php
echo "<pre>";

echo system("php -l /TArea/user/config/saveproj.php");


?>
