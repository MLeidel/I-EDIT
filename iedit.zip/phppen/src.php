<?php
$r = copy("thing.html", "else.html");
if ($r === TRUE)
	echo $r;
else
  echo "FALSE";

?>
