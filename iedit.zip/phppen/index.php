<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset='UTF-8'>
	<meta name='viewport' content='width=device-width, initial-scale=1'>
	<title>PhpPen</title>
	<link rel="stylesheet" href="style.css" type="text/css">
	<script type="text/javascript" src="../js/myJS-1.1.min.js"></script>
	<script type="text/javascript" src="../js/mta_1.0_min.js"></script>
</head>
<body>
<br>
<input type="button" onclick="getphp()" value=" execute ">&nbsp;&nbsp;&nbsp;
	<a href="http://php.net/" target="_blank">PHP Website</a> 
<textarea id="TA" rows="20" cols="100" wrap="off" spellcheck="false">
<?php echo $src ?>
</textarea>

<!-- 
src=uri name=cdata longdesc=uri width=length height=length 
align=[ top | middle | bottom | left | right ] frameborder=[ 1 | 0 ] 
marginwidth=pixels marginheight=pixels scrolling=[ yes | no | auto ] 
-->
<iframe src="src.php" scrolling="auto" height="400" width="98%" id="FR" frameborder="1">
</iframe>

<script type="text/javascript">

function getphp() {
	var src = JS.val("#TA");
	JS.webpost("doPHP.php", 1, `src=${src}`) // send and receive
}

function webresponse(n, text) { 
	JS.attr("#FR", "src", "src.php");
}

Mta.listeners.initialize("TA");
</script>
</body>
</html>
