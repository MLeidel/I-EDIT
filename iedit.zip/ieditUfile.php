<?php
extract($_GET); // cdir
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>I-EDIT File Uploader</title>
  <style>
		body {
			font: normal 14pt sans-serif;
			/*background-image: url(darkback.jpg);*/
			background-color: #cccccc;
			margin: 20px;
		}
		input {
		  font: normal 14pt sans-serif;
		}
		input:hover {
		  background: #bbbbbb;
		}

  </style>
</head>
<body id="B">
<h2>I-EDIT File Upload to <?php echo $cdir ?>/</h2>
<form enctype="multipart/form-data" action="ieditUhand.php" method="POST">
	<input type="hidden" name="MAX_FILE_SIZE" value="5000000" />
	<input type="hidden" name="cdir" value="<?php echo $cdir ?>" />
	Select file: <input name="userfile" type="file" />
	<input type="submit" value=" Upload File " />
</form>
</body>
</html>
