<?php
extract($_GET); // cdir
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>I-Edit File Uploader</title>
  <script type="text/javascript" src="js/myJS-1.1.min.js"></script>
  <style>
  body {
    margin: 0px;
    background: #ddd;
    font-family: sans-serif;
    font-size: 12pt;
    margin-left: 25px;
  }

  /* ----------------------------------------- */

  :root {
    --button-bkg: #999; /* button background color */
    --button-clr: black; /* button text color */
    --button-hov: white; /* button hover text color */
    --button-rad: 2px; /* button corner radius */
  }

  /* ----------------------------------------- */

  input[type=button],
  input[type=submit],
  input[type=file] {
    background-color: var(--button-bkg);
    border: none;
    color: var(--button-clr);
    padding: 4px 8px;
    text-align: center;
    display: inline-block;
    font-size: inherit;
    margin: 2px 2px;
    cursor: pointer;
    border-radius: var(--button-rad);
  }

  input[type=button]:enabled:hover,
  input[type=submit]:enabled:hover {
    color: var(--button-hov);
  }

  input[type=button]:disabled,
  input[type=submit]:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }

  a:hover {
    text-decoration: none;
    background: var(--button-bkg);
    color: var(--button-hov);
  }

  </style>
</head>
<body id="B">
<h2>I-Edit File Upload to <?php echo $cdir ?>/</h2>
<form enctype="multipart/form-data" action="ieditUhand.php" method="POST">
	<input type="hidden" name="MAX_FILE_SIZE" value="5000000" />
	<input type="hidden" name="cdir" value="<?php echo $cdir ?>" />
	Select file: <input name="userfile" type="file" />
	<input type="submit" value=" Upload File " />
</form>
</body>
</html>
