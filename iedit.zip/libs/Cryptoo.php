<?php 
/*
CLASS Cryptoo (no constructor)
functions:
  Cryptoo->setKey() [without setKey a static key is used]
  Cryptoo->delKey()
  Cryptoo->exportKey() : base64 encoded text
  Cryptoo->importKey(AN EXPORTED KEY)
  Cryptoo->encrypt(PLAIN) : base64 encoded text
  Cryptoo->decrypt(ENCRYPTED) : Plain text
*/
class Cryptoo {
  
  private $key;

  function encrypt($message) {
      if (!isset($this->key)) {
        $this->key = base64_decode("DTeISjcHuOI8obtJsaIEIUyDnRSplfpvN3SZybGboj8=");
      }
      $nonce = random_bytes(
          SODIUM_CRYPTO_SECRETBOX_NONCEBYTES
      );
  
      $cipher = base64_encode(
          $nonce.
          sodium_crypto_secretbox(
              $message,
              $nonce,
              $this->key
          )
      );
      sodium_memzero($message);
      return $cipher;
  }
  
  function decrypt($encrypted) {
      if (!isset($this->key)) {
        $this->key = base64_decode("DTeISjcHuOI8obtJsaIEIUyDnRSplfpvN3SZybGboj8=");
      }
      $decoded = base64_decode($encrypted);
      if ($decoded === false) {
          throw new Exception('Encoding failed');
      }
      if (mb_strlen($decoded, '8bit') < (SODIUM_CRYPTO_SECRETBOX_NONCEBYTES + SODIUM_CRYPTO_SECRETBOX_MACBYTES)) {
          throw new Exception('The message was truncated');
      }
      $nonce = mb_substr($decoded, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES, '8bit');
      $ciphertext = mb_substr($decoded, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES, null, '8bit');
  
      $plain = sodium_crypto_secretbox_open(
          $ciphertext,
          $nonce,
          $this->key
      );
      if ($plain === false) {
           throw new Exception('The message was tampered with in transit');
      }
      sodium_memzero($ciphertext);
      return $plain;
  }
  
  function setKey() {
    $this->key = sodium_crypto_secretbox_keygen();
  }
  
  function importKey($K) {
    $this->key = base64_decode($K);
  }
  
  function exportKey() {
    return base64_encode($this->key);
  }
  
  function delKey() {
    sodium_memzero($this->key);
  }
  
} // end of class
?>

