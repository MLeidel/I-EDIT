<?php // createList.php
/* HTML <select> functions
createList(
  array of items or csv string,
  ID (string),
  onchange command or FALSE,
  first option ITEM (string) or FALSE,
  size attribute or FALSE
);
Returns the HTML select/option code
EXAMPLES:
  see createList.html
*/

function createList($items, $id, $onchg=FALSE, $firstopt=FALSE, $size=FALSE) {
  if (is_array($items)) {
    $ar = $items;
  } else {
    $ar = explode( ",", $items );  // items was a CSV string
  }
  $sz = "";
  if ($size !== FALSE) $sz = "size='$size'";
  $oc = "";
  if ($onchg !== FALSE) $oc = "onchange='$onchg'";
  
  $html = "<select id=\"$id\" $sz $oc>\n";
 
  if ($firstopt !== FALSE) {
    $html .= "<option>$firstopt</option>\n";
  }
	for ($x = 0; $x < count($ar); $x++) {
		$html .= "<option>$ar[$x]</option>\n";
	}
	$html .= "</select>\n";
	return $html;
} // end function
?>


