<?php 
/* Arcgz.php (libs/Arcgz.php)
compress a file
uncompress a file
read a compressed file
----------------------
Example:
$zip = new Arcgz();
echo $zip->putgz("css.html", "css.gz");
sleep(1);
echo $zip->readgz("css.gz");
sleep(1);
echo $zip->putungz("css.gz", "css2.html");
*/

class Arcgz {

  function putgz($infile, $outgzfile) {
  	$file = $infile;
  	$gzfile = $outgzfile;
  	$fp = gzopen ($gzfile, 'w9');
  	$n = gzwrite ($fp, file_get_contents($file));
  	gzclose($fp);
  	if ($n > 0) {
  	  return "Success";
  	}	else {
  	  return "Failed";
  	}
  }

  function readgz($infile) {
    return file_get_contents('compress.zlib://'.$infile);
  }

  function putungz($ingzfile, $outfile) {
    $r = file_put_contents( $outfile, file_get_contents('compress.zlib://'.$ingzfile) );
    if ($r === FALSE) {
      return "Failed";
    } else {
      return "Success";
    }
  }

}
