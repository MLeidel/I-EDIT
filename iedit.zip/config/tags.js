const atags = [{
	"tag": "ajson",
	"tagx": "var ajson = [\n	{\"\":\"\"},\n	{\"\":\"\"}\n	];\n"
}, {
	"tag": "a",
	"tagx": "<a href=\"\" id=\"\" target=\"_blank\"></a>"
}, {
	"tag": "br",
	"tagx": "<br style=\"clear:left;\">"
}, {
	"tag": "button",
	"tagx": "<input type=\"button\" id=\"\" value=\"\">"
}, {
	"tag": "checkbox",
	"tagx": "<label for='AA'>description</label>\n<input type='checkbox' id='AA' name='postfield' value='postvalue'>"
}, {
	"tag": "com",
	"tagx": "/***\n\n***/\n"
}, {
	"tag": "dbinc",
	"tagx": "require \"$_SERVER[DOCUMENT_ROOT]/inc_isites_db.php\";"
}, {
	"tag": "db",
	"tagx": "$db = new SQLite3('');\n"
}, {
	"tag": "dbq",
	"tagx": "$results = $db->query($sql);"
}, {
	"tag": "dbf",
	"tagx": "$ar = $results->fetchArray();\nif (!$ar) {\n	die(\"No rows returned\");\n}"
}, {
	"tag": "dbe",
	"tagx": "$name = SQLite3::escapeString($name);"
}, {
	"tag": "dbw",
	"tagx": "do {\n	// process rows in $ar\n} while ( $ar = $results->fetchArray() );"
}, {
	"tag": "dbx",
	"tagx": "$db->exec($sql) or die('Insert/Update Failed<br>' . $sql);"
}, {
	"tag": "echo",
	"tagx": "<?php echo '' ?>"
}, {
	"tag": "getcook",
	"tagx": "getCookie(\"\");\n"
}, {
	"tag": "err",
	"tagx": "error_reporting(E_ALL);\nini_set('display_errors', '1');"
}, {
	"tag": "header",
	"tagx": "header(\"Location: \");"
}, {
	"tag": "html",
	"tagx": "<!DOCTYPE HTML>\n<html lang=\"en-US\">\n<head>\n	<meta charset='UTF-8'>\n	<meta name='viewport' content='width=device-width, initial-scale=1'>\n	<title></title>\n</head>\n<body>\n\n</body>\n</html>\n"
}, {
	"tag": "id",
	"tagx": "document.getElementById('')"
}, {
	"tag": "input",
	"tagx": "<input type=\"text\" id=\"\" value=\"\">"
}, {
	"tag": "ipsum",
	"tagx": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus scelerisque sodales condimentum. "
}, {
	"tag": "js",
	"tagx": "<script type=\"text/javascript\" src=\"../js/myJS-1.1.min.js\"></script>"
}, {
	"tag": "label",
	"tagx": "<label for=\"id\"></label>"
}, {
	"tag": "link",
	"tagx": "<link rel=\"stylesheet\" href=\"\" type=\"text/css\">"
}, {
	"tag": "man",
	"tagx": "<link rel=\"manifest\" href=\"manifest.json\">\n"
}, {
	"tag": "manifest",
	"tagx": "{\n	\"short_name\": \"\",\n	\"name\": \"\",\n	\"icons\": [\n		{\n			\"src\": \".png\",\n			\"sizes\": \"x\",\n			\"type\": \"image/png\"\n		}\n	],\n	\"start_url\": \"index.html\",\n	\"background_color\": \"\",\n	\"theme_color\": \"black\",\n	\"display\": \"standalone\"\n}\n"
}, {
	"tag": "mdimage",
	"tagx": '![alttext](http:// "title")'
}, {
	"tag": "mdlink",
	"tagx": '[linktext](http:// "title")'
}, {
	"tag": "mdtable",
	"tagx": "| xxx | xxx | xxx | xxx |\n| --- | --- | --- | --- |\n"
}, {
	"tag": "option",
	"tagx": "alert(selobj.options[selobj.selectedIndex].text)"
}, {
	"tag": "php",
	"tagx": "<?php ?>"
}, {
	"tag": "query",
	"tagx": '$res = mysqli_query($mysqli, $sql) or die("DIE:<br>".$sql);\n$row = mysqli_fetch_assoc($res);\nif (mysqli_num_rows($res) > 0) {\n	extract($row);\n}\n'
}, {
	"tag": "radio",
	"tagx": "<label for='AA'>description</label>\n<input type='radio' id='AA' name='postfield' value='postvalue' checked>"
}, {
	"tag": "script2",
	"tagx": "<script type=\"text/javascript\" src=\"\"><\/script>"
}, {
	"tag": "script",
	"tagx": "<script type=\"text/javascript\"><\/script>"
}, {
	"tag": "script",
	"tagx": "<script type=\"text/javascript\"><\/script>"
}, {
	"tag": "setcook",
	"tagx": "setCookie(\"name\",\"value\",\"days\");\n"
}, {
	"tag": "style",
	"tagx": "<style	type=\"text/css\"><\/style>"
}, {
	"tag": "table",
	"tagx": "<style type=\"text/css\">\ntable, th, td \{\n	border: 1px solid black;\n	margin: auto; /* center */\n}\n\</style>\n\n<table>\n	<tr>\n		<td> </td>\n		<td> </td>\n	</tr>\n	<tr>\n		\<td> </td>\n		<td> </td>\n	</tr>\n</table>\n"
}, {
	"tag": "ta",
	"tagx": "<textarea id=\"\" rows=\"\" cols=\"\" wrap=\"off\"></textarea>"
}, {
	"tag": "tr",
	"tagx": "<tr>\n	<td></td>\n	<td></td>\n</tr>"
}, {
	"tag": "ul",
	"tagx": "<ul>\n <li></li>\n <li></li>\n <li></li>\n <li></li>\n</ul>\n"
}, {
	"tag": "xxxxx",
	"tagx": "xxxxx"
}];
