<?php 
/****
exec.php
Use 'grep' or 'find' for everything
under ../user/. Home directory is 'config'.
****/
extract($_POST);

if (isset($grep)) {
	exec("grep -rn --include='$gfilemask' '$gtarget' ../$gpath", $arro);
}
else {
	if (isset($find)) {
		exec("find ../$gpath -name '$findfile'", $arro);
	}
}
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Grep & Find</title>
	<style type="text/css">
	fieldset { display: inline; background: Ivory; float: left;}
	input { float: right; }
	label { float: left; }
	code {
		font: normal 10pt/12pt monospace;
		white-space: pre;
	}
	body {
		margin-left: 25px;
	}
	</style>
</head>
<body>
<h1>I-EDIT File System</h1>
<fieldset>
<legend style="letter-spacing:4px;font-style:bold;color:#5E5C8C;font-variant: small-caps;">
	&nbsp;Grep Request &nbsp;</legend>
<form name="frm1" method="post">
	<label for="IN0">Path</label>
	<input type="text" id="IN0" name="gpath" value="<?php echo $gpath ?>" 
		title="path on user/ or leave blank" placeholder="appdir/ | blank">
	<br><br>
	<label for="IN1">Grep Target</label>
	<input type="text" id="IN1" name="gtarget" value="<?php echo $gtarget ?>" title="text to search for">
	<br><br>
	<label for="IN2">Grep File Mask&nbsp;&nbsp;</label>
	<input type="text" id="IN2" name="gfilemask" value="<?php echo $gfilemask ?>" title="file or file type">
	<br><br>
	<input type="submit" name="grep" value=" Run ">
</form>
</fieldset>
<div style="float: left;"><br>&nbsp;&nbsp;&nbsp;<br><br><br><br></div><br><br>
<fieldset>
<legend style="letter-spacing:4px;font-style:bold;color:#5E5C8C;font-variant: small-caps;">
	&nbsp;Find File Request&nbsp;</legend>

<form name="frm2" method="post">
	<label for="IN3">Path</label>
	<input type="text" id="IN3" name="gpath" value="<?php echo $gpath ?>" 
		title="path on user/ or leave blank" placeholder="appdir/ | blank">
	<br><br>
	<label for="INF">Find File Mask&nbsp;&nbsp;</label>
	<input type="text" id="INF" name="findfile" value="">
	<br><br>
	<input type="submit" name="find" value=" Run ">
</form>
</fieldset>
<p style="clear: both;">
<code>
<?php 

if (isset($arro)) {
  $first = true;
  foreach ($arro as $value)
    if ($value !== "../$gpath") {
  		echo htmlentities($value) . " " . filesize($value) . " " . 
  		    date ("F d Y H:i:s.", filemtime($value)) . "\n";
    }
}
?>
</code>
</p>
</body>
</html>
