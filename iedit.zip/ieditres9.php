<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>I-EDIT</title>
	<style	type="text/css">
	table {
		float: left;
		padding: 6px;
	}
	body {
		margin-left: 25px;
		background-color: #cdcdcd;
		font: normal 12pt/18pt sans-serif;
	}

	</style>
	<script type="text/javascript">
	function goSnook() {
		var c1, c2;
		c1 = document.getElementById('BG').value;
		c2 = document.getElementById('FG').value;
		location = "https://snook.ca/technical/colour_contrast/colour.html#bg=" + c1 + ",fg=" + c2;
	}

	</script>
</head>
<body>
<h1>I-EDIT Designing Tools</h1>
<table><tr><td>
<form name="f1">
Enter text to encrypt below
<P><INPUT size=35 name="text1"></P>
<INPUT class="btn" type="button" value="PHP encryption" onclick="location='res9.php?s='+document.f1.text1.value">
<?php
	if (isset($_GET['s']))
	{
		$str = $_GET['s'];
		echo "Text to encrypt: ".$str."<br><br>";
		echo "Use: if (md5(\$var) == \"".md5($str)."\"<br><br>";
		echo "crypt function: ".crypt($str,"seed");
	}
?>
</form>
</td><td>
<br>
<a href="http://paletton.com/#uid=5000u0kllllaFw0g0qFqFg0w0aF" target="_blank" style="float:left;">Paletton Designer</a>
<br>
<a href="https://webcode.tools/css-generator" target="_blank">CSS-Generator</a>
<br>
<a href="https://www.google.com/search?q=webpage+backgrounds" target="_blank">Google Image for Backgrounds</a>
<br>
<a href="http://www.flaticon.com/" target="_blank">Flaticon</a>
<br>
<a href="https://docs.google.com/drawings/" target="_blank">Google Draw</a>
<br>
</td><td>
<fieldset style="display:inline;font: normal 10pt monospace;">
Enter background #<input type="search" id="BG" value=""><br>
Enter foreground #<input type="search" id="FG" value=""><br>
<input type="button" onclick="goSnook();" value="Goto Snook site">
</fieldset
</td>
</tr><table>
<br><br clear="all">

<table border="0">
<tr>
<td colspan="3" style="background:whitesmoke;text-align:left;"><span style="font-size: 120%;"><b>Pink colors</b></span></td>
</tr>
<tr style="background:pink;color:black">
<td><code>Pink</code></td>
<td><code>FFC0CB</code></td>
<td><code>255192203</code></td>
</tr>
<tr style="background:lightpink;color:black">
<td><code>LightPink</code></td>
<td><code>FFB6C1</code></td>
<td><code>255182193</code></td>
</tr>
<tr style="background:hotpink;color:white">
<td><code>HotPink</code></td>
<td><code>FF69B4</code></td>
<td><code>255105180</code></td>
</tr>
<tr style="background:deeppink;color:white">
<td><code>DeepPink</code></td>
<td><code>FF1493</code></td>
<td><code>25520147</code></td>
</tr>
<tr style="background:palevioletred;color:white">
<td><code>PaleVioletRed</code></td>
<td><code>DB7093</code></td>
<td><code>219112147</code></td>
</tr>
<tr style="background:mediumvioletred;color:white">
<td><code>MediumVioletRed</code></td>
<td><code>C71585</code></td>
<td><code>19921133</code></td>
</tr>
<tr>
<td colspan="3" style="background:whitesmoke;text-align:left;"><span style="font-size: 120%;"><b>Red colors</b></span></td>
</tr>
<tr style="background:lightsalmon;color:black">
<td><code>LightSalmon</code></td>
<td><code>FFA07A</code></td>
<td><code>255160122</code></td>
</tr>
<tr style="background:salmon;color:black">
<td><code>Salmon</code></td>
<td><code>FA8072</code></td>
<td><code>250128114</code></td>
</tr>
<tr style="background:darksalmon;color:black">
<td><code>DarkSalmon</code></td>
<td><code>E9967A</code></td>
<td><code>233150122</code></td>
</tr>
<tr style="background:lightcoral;color:black">
<td><code>LightCoral</code></td>
<td><code>F08080</code></td>
<td><code>240128128</code></td>
</tr>
<tr style="background:indianred;color:white">
<td><code>IndianRed</code></td>
<td><code>CD5C5C</code></td>
<td><code>2059292</code></td>
</tr>
<tr style="background:crimson;color:white;color:white">
<td><code>Crimson</code></td>
<td><code>DC143C</code></td>
<td><code>2202060</code></td>
</tr>
<tr style="background:fireBrick;color:white">
<td><code>FireBrick</code></td>
<td><code>B22222</code></td>
<td><code>1783434</code></td>
</tr>
<tr style="background:darkred;color:white">
<td><code>DarkRed</code></td>
<td><code>8B0000</code></td>
<td><code>13900</code></td>
</tr>
<tr style="background:red;color:white">
<td><code>Red</code></td>
<td><code>FF0000</code></td>
<td><code>25500</code></td>
</tr>
<tr>
<td colspan="3" style="background:whitesmoke;text-align:left;"><span style="font-size: 120%;"><b>Orange colors</b></span></td>
</tr>
<tr style="background:orangered;color:white">
<td><code>OrangeRed</code></td>
<td><code>FF4500</code></td>
<td><code>255690</code></td>
</tr>
<tr style="background:tomato;color:white">
<td><code>Tomato</code></td>
<td><code>FF6347</code></td>
<td><code>2559971</code></td>
</tr>
<tr style="background:coral;color:black">
<td><code>Coral</code></td>
<td><code>FF7F50</code></td>
<td><code>25512780</code></td>
</tr>
<tr style="background:darkorange;color:black">
<td><code>DarkOrange</code></td>
<td><code>FF8C00</code></td>
<td><code>2551400</code></td>
</tr>
<tr style="background:orange;color:black">
<td><code>Orange</code></td>
<td><code>FFA500</code></td>
<td><code>2551650</code></td>
</tr>
<tr>
<td colspan="3" style="background:whitesmoke;text-align:left;"><span style="font-size: 120%;"><b>Yellow colors</b></span></td>
</tr>
<tr style="background:yellow;color:black">
<td><code>Yellow</code></td>
<td><code>FFFF00</code></td>
<td><code>2552550</code></td>
</tr>
<tr style="background:lightyellow;color:black">
<td><code>LightYellow</code></td>
<td><code>FFFFE0</code></td>
<td><code>255255224</code></td>
</tr>
<tr style="background:lemonchiffon;color:black">
<td><code>LemonChiffon</code></td>
<td><code>FFFACD</code></td>
<td><code>255250205</code></td>
</tr>
<tr style="background:lightgoldenrodyellow;color:black">
<td><code>LightGoldenrodYellow</code></td>
<td><code>FAFAD2</code></td>
<td><code>250250210</code></td>
</tr>
<tr style="background:papayawhip;color:black">
<td><code>PapayaWhip</code></td>
<td><code>FFEFD5</code></td>
<td><code>255239213</code></td>
</tr>
<tr style="background:moccasin;color:black">
<td><code>Moccasin</code></td>
<td><code>FFE4B5</code></td>
<td><code>255228181</code></td>
</tr>
<tr style="background:peachpuff;color:black">
<td><code>PeachPuff</code></td>
<td><code>FFDAB9</code></td>
<td><code>255218185</code></td>
</tr>
<tr style="background:palegoldenrod;color:black">
<td><code>PaleGoldenrod</code></td>
<td><code>EEE8AA</code></td>
<td><code>238232170</code></td>
</tr>
<tr style="background:khaki;color:black">
<td><code>Khaki</code></td>
<td><code>F0E68C</code></td>
<td><code>240230140</code></td>
</tr>
<tr style="background:darkkhaki;color:black">
<td><code>DarkKhaki</code></td>
<td><code>BDB76B</code></td>
<td><code>189183107</code></td>
</tr>
<tr style="background:gold;color:black">
<td><code>Gold</code></td>
<td><code>FFD700</code></td>
<td><code>2552150</code></td>
</tr>
<tr>
<td colspan="3" style="background:whitesmoke;text-align:left;"><span style="font-size: 120%;"><b>Brown colors</b></span></td>
</tr>
<tr style="background:cornsilk;color:black">
<td><code>Cornsilk</code></td>
<td><code>FFF8DC</code></td>
<td><code>255248220</code></td>
</tr>
<tr style="background:blanchedalmond;color:black">
<td><code>BlanchedAlmond</code></td>
<td><code>FFEBCD</code></td>
<td><code>255235205</code></td>
</tr>
<tr style="background:bisque;color:black">
<td><code>Bisque</code></td>
<td><code>FFE4C4</code></td>
<td><code>255228196</code></td>
</tr>
<tr style="background:navajowhite;color:black">
<td><code>NavajoWhite</code></td>
<td><code>FFDEAD</code></td>
<td><code>255222173</code></td>
</tr>
<tr style="background:wheat;color:black">
<td><code>Wheat</code></td>
<td><code>F5DEB3</code></td>
<td><code>245222179</code></td>
</tr>
<tr style="background:burlywood;color:black">
<td><code>BurlyWood</code></td>
<td><code>DEB887</code></td>
<td><code>222184135</code></td>
</tr>
<tr style="background:tan;color:black">
<td><code>Tan</code></td>
<td><code>D2B48C</code></td>
<td><code>210180140</code></td>
</tr>
<tr style="background:rosybrown;color:black">
<td><code>RosyBrown</code></td>
<td><code>BC8F8F</code></td>
<td><code>188143143</code></td>
</tr>
<tr style="background:sandybrown;color:black">
<td><code>SandyBrown</code></td>
<td><code>F4A460</code></td>
<td><code>24416496</code></td>
</tr>
<tr style="background:goldenrod;color:black">
<td><code>Goldenrod</code></td>
<td><code>DAA520</code></td>
<td><code>21816532</code></td>
</tr>
<tr style="background:darkgoldenrod;color:black">
<td><code>DarkGoldenrod</code></td>
<td><code>B8860B</code></td>
<td><code>18413411</code></td>
</tr>
<tr style="background:Peru;color:black">
<td><code>Peru</code></td>
<td><code>CD853F</code></td>
<td><code>20513363</code></td>
</tr>
<tr style="background:chocolate;color:white">
<td><code>Chocolate</code></td>
<td><code>D2691E</code></td>
<td><code>21010530</code></td>
</tr>
<tr style="background:saddlebrown;color:white">
<td><code>SaddleBrown</code></td>
<td><code>8B4513</code></td>
<td><code>1396919</code></td>
</tr>
<tr style="background:sienna;color:white">
<td><code>Sienna</code></td>
<td><code>A0522D</code></td>
<td><code>1608245</code></td>
</tr>
<tr style="background:brown;color:white">
<td><code>Brown</code></td>
<td><code>A52A2A</code></td>
<td><code>1654242</code></td>
</tr>
<tr style="background:maroon;color:white">
<td><code>Maroon</code></td>
<td><code>800000</code></td>
<td><code>12800</code></td>
</tr>
</table>
</td>
<td>
<table>
<tr>
<td colspan="3" style="background:whitesmoke;text-align:left;"><span style="font-size: 120%;"><b>Green colors</b></span></td>
</tr>
<tr style="background:darkolivegreen;color:white">
<td><code>DarkOliveGreen</code></td>
<td><code>556B2F</code></td>
<td><code>8510747</code></td>
</tr>
<tr style="background:olive;color:white">
<td><code>Olive</code></td>
<td><code>808000</code></td>
<td><code>1281280</code></td>
</tr>
<tr style="background:olivedrab;color:white">
<td><code>OliveDrab</code></td>
<td><code>6B8E23</code></td>
<td><code>10714235</code></td>
</tr>
<tr style="background:yellowgreen;color:black">
<td><code>YellowGreen</code></td>
<td><code>9ACD32</code></td>
<td><code>15420550</code></td>
</tr>
<tr style="background:limegreen;color:black">
<td><code>LimeGreen</code></td>
<td><code>32CD32</code></td>
<td><code>5020550</code></td>
</tr>
<tr style="background:lime;color:black">
<td><code>Lime</code></td>
<td><code>00FF00</code></td>
<td><code>02550</code></td>
</tr>
<tr style="background:lawngreen;color:black">
<td><code>LawnGreen</code></td>
<td><code>7CFC00</code></td>
<td><code>1242520</code></td>
</tr>
<tr style="background:chartreuse;color:black">
<td><code>Chartreuse</code></td>
<td><code>7FFF00</code></td>
<td><code>1272550</code></td>
</tr>
<tr style="background:greenyellow;color:black">
<td><code>GreenYellow</code></td>
<td><code>ADFF2F</code></td>
<td><code>17325547</code></td>
</tr>
<tr style="background:springgreen;color:black">
<td><code>SpringGreen</code></td>
<td><code>00FF7F</code></td>
<td><code>0255127</code></td>
</tr>
<tr style="background:mediumspringgreen;color:black">
<td><code>MediumSpringGreen</code></td>
<td><code>00FA9A</code></td>
<td><code>0250154</code></td>
</tr>
<tr style="background:lightgreen;color:black">
<td><code>LightGreen</code></td>
<td><code>90EE90</code></td>
<td><code>144238144</code></td>
</tr>
<tr style="background:palegreen;color:black">
<td><code>PaleGreen</code></td>
<td><code>98FB98</code></td>
<td><code>152251152</code></td>
</tr>
<tr style="background:darkseagreen;color:black">
<td><code>DarkSeaGreen</code></td>
<td><code>8FBC8F</code></td>
<td><code>143188143</code></td>
</tr>
<tr style="background:mediumaquamarine;color:black">
<td><code>MediumAquamarine</code></td>
<td><code>66CDAA</code></td>
<td><code>102205170</code></td>
</tr>
<tr style="background:mediumseagreen;color:black">
<td><code>MediumSeaGreen</code></td>
<td><code>3CB371</code></td>
<td><code>60179113</code></td>
</tr>
<tr style="background:seagreen;color:white">
<td><code>SeaGreen</code></td>
<td><code>2E8B57</code></td>
<td><code>4613987</code></td>
</tr>
<tr style="background:forestgreen;color:white">
<td><code>ForestGreen</code></td>
<td><code>228B22</code></td>
<td><code>3413934</code></td>
</tr>
<tr style="background:green;color:white">
<td><code>Green</code></td>
<td><code>008000</code></td>
<td><code>01280</code></td>
</tr>
<tr style="background:darkgreen;color:white">
<td><code>DarkGreen</code></td>
<td><code>006400</code></td>
<td><code>01000</code></td>
</tr>
<tr>
<td colspan="3" style="background:whitesmoke;text-align:left;"><span style="font-size: 120%;"><b>Cyan colors</b></span></td>
</tr>
<tr style="background:aqua;color:black">
<td><code>Aqua</code></td>
<td><code>00FFFF</code></td>
<td><code>0255255</code></td>
</tr>
<tr style="background:cyan;color:black">
<td><code>Cyan</code></td>
<td><code>00FFFF</code></td>
<td><code>0255255</code></td>
</tr>
<tr style="background:lightcyan;color:black">
<td><code>LightCyan</code></td>
<td><code>E0FFFF</code></td>
<td><code>224255255</code></td>
</tr>
<tr style="background:paleturquoise;color:black">
<td><code>PaleTurquoise</code></td>
<td><code>AFEEEE</code></td>
<td><code>175238238</code></td>
</tr>
<tr style="background:aquamarine;color:black">
<td><code>Aquamarine</code></td>
<td><code>7FFFD4</code></td>
<td><code>127255212</code></td>
</tr>
<tr style="background:turquoise;color:black">
<td><code>Turquoise</code></td>
<td><code>40E0D0</code></td>
<td><code>64224208</code></td>
</tr>
<tr style="background:mediumturquoise;color:black">
<td><code>MediumTurquoise</code></td>
<td><code>48D1CC</code></td>
<td><code>72209204</code></td>
</tr>
<tr style="background:darkturquoise;color:black">
<td><code>DarkTurquoise</code></td>
<td><code>00CED1</code></td>
<td><code>0206209</code></td>
</tr>
<tr style="background:lightseagreen;color:black">
<td><code>LightSeaGreen</code></td>
<td><code>20B2AA</code></td>
<td><code>32178170</code></td>
</tr>
<tr style="background:cadetblue;color:white">
<td><code>CadetBlue</code></td>
<td><code>5F9EA0</code></td>
<td><code>95158160</code></td>
</tr>
<tr style="background:darkcyan;color:white">
<td><code>DarkCyan</code></td>
<td><code>008B8B</code></td>
<td><code>0139139</code></td>
</tr>
<tr style="background:teal;color:white">
<td><code>Teal</code></td>
<td><code>008080</code></td>
<td><code>0128128</code></td>
</tr>
<tr>
<td colspan="3" style="background:whitesmoke;text-align:left;"><span style="font-size: 120%;"><b>Blue colors</b></span></td>
</tr>
<tr style="background:lightsteelblue;color:black">
<td><code>LightSteelBlue</code></td>
<td><code>B0C4DE</code></td>
<td><code>176196222</code></td>
</tr>
<tr style="background:powderblue;color:black">
<td><code>PowderBlue</code></td>
<td><code>B0E0E6</code></td>
<td><code>176224230</code></td>
</tr>
<tr style="background:lightblue;color:black">
<td><code>LightBlue</code></td>
<td><code>ADD8E6</code></td>
<td><code>173216230</code></td>
</tr>
<tr style="background:skyblue;color:black">
<td><code>SkyBlue</code></td>
<td><code>87CEEB</code></td>
<td><code>135206235</code></td>
</tr>
<tr style="background:lightskyblue;color:black">
<td><code>LightSkyBlue</code></td>
<td><code>87CEFA</code></td>
<td><code>135206250</code></td>
</tr>
<tr style="background:deepskyblue;color:black">
<td><code>DeepSkyBlue</code></td>
<td><code>00BFFF</code></td>
<td><code>0191255</code></td>
</tr>
<tr style="background:dodgerblue;color:black">
<td><code>DodgerBlue</code></td>
<td><code>1E90FF</code></td>
<td><code>30144255</code></td>
</tr>
<tr style="background:cornflowerblue;color:black">
<td><code>CornflowerBlue</code></td>
<td><code>6495ED</code></td>
<td><code>100149237</code></td>
</tr>
<tr style="background:steelblue;color:white">
<td><code>SteelBlue</code></td>
<td><code>4682B4</code></td>
<td><code>70130180</code></td>
</tr>
<tr style="background:royalblue;color:white">
<td><code>RoyalBlue</code></td>
<td><code>4169E1</code></td>
<td><code>65105225</code></td>
</tr>
<tr style="background:blue;color:white">
<td><code>Blue</code></td>
<td><code>0000FF</code></td>
<td><code>00255</code></td>
</tr>
<tr style="background:mediumblue;color:white">
<td><code>MediumBlue</code></td>
<td><code>0000CD</code></td>
<td><code>00205</code></td>
</tr>
<tr style="background:darkblue;color:white">
<td><code>DarkBlue</code></td>
<td><code>00008B</code></td>
<td><code>00139</code></td>
</tr>
<tr style="background:navy;color:white">
<td><code>Navy</code></td>
<td><code>000080</code></td>
<td><code>00128</code></td>
</tr>
<tr style="background:midnightblue;color:white">
<td><code>MidnightBlue</code></td>
<td><code>191970</code></td>
<td><code>2525112</code></td>
</tr>
</table>
</td>
<td>
<table>
<tr>
<td colspan="3" style="background:whitesmoke;text-align:left;"><span style="font-size: 120%;"><b>Purple, violet, and magenta colors</b></span></td>
</tr>
<tr style="background:lavender;color:black">
<td><code>Lavender</code></td>
<td><code>E6E6FA</code></td>
<td><code>230230250</code></td>
</tr>
<tr style="background:thistle;color:black">
<td><code>Thistle</code></td>
<td><code>D8BFD8</code></td>
<td><code>216191216</code></td>
</tr>
<tr style="background:plum;color:black">
<td><code>Plum</code></td>
<td><code>DDA0DD</code></td>
<td><code>221160221</code></td>
</tr>
<tr style="background:violet;color:black">
<td><code>Violet</code></td>
<td><code>EE82EE</code></td>
<td><code>238130238</code></td>
</tr>
<tr style="background:orchid;color:black">
<td><code>Orchid</code></td>
<td><code>DA70D6</code></td>
<td><code>218112214</code></td>
</tr>
<tr style="background:fuchsia;color:black">
<td><code>Fuchsia</code></td>
<td><code>FF00FF</code></td>
<td><code>2550255</code></td>
</tr>
<tr style="background:Magenta;color:black">
<td><code>Magenta</code></td>
<td><code>FF00FF</code></td>
<td><code>2550255</code></td>
</tr>
<tr style="background:mediumorchid;color:white">
<td><code>MediumOrchid</code></td>
<td><code>BA55D3</code></td>
<td><code>18685211</code></td>
</tr>
<tr style="background:mediumpurple;color:white">
<td><code>MediumPurple</code></td>
<td><code>9370DB</code></td>
<td><code>147112219</code></td>
</tr>
<tr style="background:blueviolet;color:white">
<td><code>BlueViolet</code></td>
<td><code>8A2BE2</code></td>
<td><code>13843226</code></td>
</tr>
<tr style="background:darkviolet;color:white">
<td><code>DarkViolet</code></td>
<td><code>9400D3</code></td>
<td><code>1480211</code></td>
</tr>
<tr style="background:darkorchid;color:white">
<td><code>DarkOrchid</code></td>
<td><code>9932CC</code></td>
<td><code>15350204</code></td>
</tr>
<tr style="background:darkmagenta;color:white">
<td><code>DarkMagenta</code></td>
<td><code>8B008B</code></td>
<td><code>1390139</code></td>
</tr>
<tr style="background:purple;color:white">
<td><code>Purple</code></td>
<td><code>800080</code></td>
<td><code>1280128</code></td>
</tr>
<tr style="background:indigo;color:white">
<td><code>Indigo</code></td>
<td><code>4B0082</code></td>
<td><code>750130</code></td>
</tr>
<tr style="background:darkslateblue;color:white">
<td><code>DarkSlateBlue</code></td>
<td><code>483D8B</code></td>
<td><code>7261139</code></td>
</tr>
<tr style="background:slateblue;color:white">
<td><code>SlateBlue</code></td>
<td><code>6A5ACD</code></td>
<td><code>10690205</code></td>
</tr>
<tr style="background:mediumslateblue;color:white">
<td><code>MediumSlateBlue</code></td>
<td><code>7B68EE</code></td>
<td><code>123104238</code></td>
</tr>
<tr>
<td colspan="3" style="background:whitesmoke;text-align:left;"><span style="font-size: 120%;"><b>White colors</b></span></td>
</tr>
<tr style="background:white;color:black">
<td><code>White</code></td>
<td><code>FFFFFF</code></td>
<td><code>255255255</code></td>
</tr>
<tr style="background:snow;color:black">
<td><code>Snow</code></td>
<td><code>FFFAFA</code></td>
<td><code>255250250</code></td>
</tr>
<tr style="background:honeydew;color:black">
<td><code>Honeydew</code></td>
<td><code>F0FFF0</code></td>
<td><code>240255240</code></td>
</tr>
<tr style="background:mintcream;color:black">
<td><code>MintCream</code></td>
<td><code>F5FFFA</code></td>
<td><code>245255250</code></td>
</tr>
<tr style="background:azure;color:black">
<td><code>Azure</code></td>
<td><code>F0FFFF</code></td>
<td><code>240255255</code></td>
</tr>
<tr style="background:aliceblue;color:black">
<td><code>AliceBlue</code></td>
<td><code>F0F8FF</code></td>
<td><code>240248255</code></td>
</tr>
<tr style="background:ghostwhite;color:black">
<td><code>GhostWhite</code></td>
<td><code>F8F8FF</code></td>
<td><code>248248255</code></td>
</tr>
<tr style="background:whitesmoke;color:black">
<td><code>WhiteSmoke</code></td>
<td><code>F5F5F5</code></td>
<td><code>245245245</code></td>
</tr>
<tr style="background:seashell;color:black">
<td><code>Seashell</code></td>
<td><code>FFF5EE</code></td>
<td><code>255245238</code></td>
</tr>
<tr style="background:beige;color:black">
<td><code>Beige</code></td>
<td><code>F5F5DC</code></td>
<td><code>245245220</code></td>
</tr>
<tr style="background:oldlace;color:black">
<td><code>OldLace</code></td>
<td><code>FDF5E6</code></td>
<td><code>253245230</code></td>
</tr>
<tr style="background:floralwhite;color:black">
<td><code>FloralWhite</code></td>
<td><code>FFFAF0</code></td>
<td><code>255250240</code></td>
</tr>
<tr style="background:ivory;color:black">
<td><code>Ivory</code></td>
<td><code>FFFFF0</code></td>
<td><code>255255240</code></td>
</tr>
<tr style="background:antiquewhite;color:black">
<td><code>AntiqueWhite</code></td>
<td><code>FAEBD7</code></td>
<td><code>250235215</code></td>
</tr>
<tr style="background:linen;color:black">
<td><code>Linen</code></td>
<td><code>FAF0E6</code></td>
<td><code>250240230</code></td>
</tr>
<tr style="background:lavenderblush;color:black">
<td><code>LavenderBlush</code></td>
<td><code>FFF0F5</code></td>
<td><code>255240245</code></td>
</tr>
<tr style="background:mistyrose;color:black">
<td><code>MistyRose</code></td>
<td><code>FFE4E1</code></td>
<td><code>255228225</code></td>
</tr>
<tr>
<td colspan="3" style="background:whitesmoke;text-align:left;"><span style="font-size: 120%;"><b>Gray and black colors</b></span></td>
</tr>
<tr style="background:gainsboro;color:black">
<td><code>Gainsboro</code></td>
<td><code>DCDCDC</code></td>
<td><code>220220220</code></td>
</tr>
<tr style="background:lightgray; color:black;">
<td><code>LightGray</code></td>
<td><code>D3D3D3</code></td>
<td><code>211211211</code></td>
</tr>
<tr style="background:silver;color:black">
<td><code>Silver</code></td>
<td><code>C0C0C0</code></td>
<td><code>192192192</code></td>
</tr>
<tr style="background:darkgray; color:black;">
<td><code>DarkGray</code></td>
<td><code>A9A9A9</code></td>
<td><code>169169169</code></td>
</tr>
<tr style="background:gray;color:white">
<td><code>Gray</code></td>
<td><code>808080</code></td>
<td><code>128128128</code></td>
</tr>
<tr style="background:dimgray; color:white;">
<td><code>DimGray</code></td>
<td><code>696969</code></td>
<td><code>105105105</code></td>
</tr>
<tr style="background:lightslategray; color:white;">
<td><code>LightSlateGray</code></td>
<td><code>778899</code></td>
<td><code>119136153</code></td>
</tr>
<tr style="background:slategray; color:white;">
<td><code>SlateGray</code></td>
<td><code>708090</code></td>
<td><code>112128144</code></td>
</tr>
<tr style="background:darkslategray; color:white;">
<td><code>DarkSlateGray</code></td>
<td><code>2F4F4F</code></td>
<td><code>477979</code></td>
</tr>
<tr style="background:black;color:white">
<td><code>Black</code></td>
<td><code>000000</code></td>
<td><code>000</code></td>
</tr>
</table>
</td>
</tr>
</table>

<br><br>
</body>
</html>
